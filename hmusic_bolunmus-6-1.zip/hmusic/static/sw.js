// HMusic service worker
//
// Amac: uygulama kabugunu (ana sayfa + ikonlar + manifest) onbellege alarak
// internet olmadan da acilabilmesini saglamak (gercek "offline PWA" destegi).
//
// Kapsam disi birakilanlar (bilincli olarak):
// - /api/* : sarki arama, akis, indirme gibi uclar HIC onbelleklenmez.
//   Bunlar zaten ag gerektirir; stale/eski veri dondurmek yaniltici olur.
// - Ses/video dosyalari: zaten ayri bir "Cevrimdisi Mod" + "Indirilenler"
//   mekanizmasiyla (gercek dosya olarak cihazda) yonetiliyor, service
//   worker cache'i buna karismaz.
//
// Strateji: ana sayfa (navigasyon) ve statik varliklar icin
// "cache-first, agdan tazele": once onbellekten hizlica goster, arka planda
// agdan guncel surumu cekip onbellegi tazele. Ag tamamen yoksa
// onbellekteki son surum gosterilir.

const CACHE_NAME = 'hmusic-shell-v1';
const SHELL_URLS = [
    '/',
    '/static/manifest.json',
    '/static/icons/icon-192.png',
    '/static/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_URLS)).catch(() => {})
    );
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((names) =>
            Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
        )
    );
    self.clients.claim();
});

self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // Sadece kendi originimizden gelen, API olmayan GET isteklerini yonet.
    if (event.request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) {
        return;
    }

    event.respondWith(
        caches.open(CACHE_NAME).then(async (cache) => {
            const cached = await cache.match(event.request);
            const networkFetch = fetch(event.request)
                .then((response) => {
                    if (response && response.status === 200) {
                        cache.put(event.request, response.clone());
                    }
                    return response;
                })
                .catch(() => null);

            if (cached) {
                // Onbellekte var: hemen onu dondur, agdan tazelemeyi arka planda dene.
                networkFetch;
                return cached;
            }
            // Onbellekte yok: agi bekle; o da basarisiz olursa ana sayfayi dene (SPA fallback).
            const networkResponse = await networkFetch;
            return networkResponse || cache.match('/');
        })
    );
});
