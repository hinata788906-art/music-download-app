# HMusic

Tek dosyalık `app.py`, bakımı kolaylaştırmak için parçalara bölündü.

## Dosya yapısı

```
hmusic/
├── app.py              # Giriş noktası: Flask app oluşturur, çalıştırır
├── config.py           # Yol/ayar sabitleri, config.json okuma-yazma, depolama seçenekleri
├── extensions.py       # Flask-Limiter kurulumu (döngüsel import olmasın diye ayrı)
├── stats.py            # Kullanım istatistikleri, IP ban listesi, güvenlik başlıkları
├── library.py          # Favoriler / çalma listeleri (kullanıcı kütüphanesi)
├── youtube.py          # YouTube arama, mp3/mp4/wav/flac indirme (yt-dlp), önbellek/skip mantığı
├── lyrics.py            # Şarkı sözü getirme (lyrics.ovh açık API'si)
├── artwork.py            # İndirilen dosyalara albüm kapağı gömme (mutagen)
├── jobs.py               # Arka planda indirme işleri + ilerleme takibi
├── cache_manager.py       # Akış önbelleği için otomatik boyut limiti (LRU tahliye)
├── search_history.py       # IP başına arama geçmişi
├── admin_auth.py            # Admin girişi: session, sabit-zamanlı karşılaştırma, brute-force kilidi
├── routes_user.py            # Kullanıcıya açık tüm sayfa ve /api/* uç noktaları
├── routes_admin.py            # Gizli /admin paneli
├── requirements.txt
├── static/
│   ├── manifest.json          # PWA manifesti ("Ana ekrana ekle" için)
│   ├── sw.js                   # Service worker (offline app shell cache)
│   └── icons/                   # Uygulama ikonları
└── templates/
    ├── user.html                # Ana uygulama arayüzü (HTML+CSS+JS)
    ├── admin.html                 # Admin paneli arayüzü
    └── admin_login.html            # Admin giriş formu
```

## Çalıştırma

```bash
cd hmusic
pip install -r requirements.txt
python app.py
```

Konsolda gizli admin paneli linki basılır. İlk girişte bu anahtar bir session
çerezine dönüştürülür — sonraki isteklerde URL'de taşınmaz.

## Bu sürümde eklenenler (özet)

- **10 bantlı grafik ekolayzır** + ayrı Bass Boost / Treble Boost / Loudness
  kontrolleri
- **Gapless playback**: crossfade kapalıyken sıradaki parça önceden
  ön yüklenip aralıksız geçiliyor
- **Gelişmiş shuffle** (Fisher-Yates, akıllı sıralama)
- **Sleep timer** (fade-out ile otomatik durdurma)
- **İndirme ilerleme göstergesi**: senkron indirme yerine job-based
  (arka plan thread + polling), gerçek yüzde barı
- **Otomatik albüm kapağı**: indirilen mp3/flac dosyalarına thumbnail gömülür
- **Şarkı sözü görünümü**: kopyala butonu, daha okunaklı tipografi
- **Arama geçmişi**: IP başına son 15 arama, chip olarak gösterilir
- **Sanatçı görünümü**: başlıktan ayrıştırılan sanatçıya göre filtreli liste
  (not: tam bir albüm/sanatçı veritabanı değil — sadece o an istemcide yüklü
  favoriler/indirilenler/arama sonuçları arasında arar)
- **Otomatik önbellek boyut limiti** (LRU tahliye, ayarlardan MB seçilebilir)
- **Sağlamlaştırılmış admin authentication**: session tabanlı giriş,
  sabit-zamanlı anahtar karşılaştırması, brute-force kilitlenmesi
- **İndirme/stream cache optimizasyonu**: aynı video zaten indirilmiş veya
  önbelleklenmişse tekrar indirilmez
- **PWA offline app shell**: service worker ana sayfa + statik varlıkları
  önbelleğe alır (API istekleri asla önbelleklenmez)

## Notlar

- `config.DOWNLOAD_FOLDER` çalışma zamanında değişebilen bir global'dir.
  Diğer modüller bunu `import config` ile modül üzerinden okur — `from
  config import DOWNLOAD_FOLDER` şeklinde kopyalamaz, aksi halde ayar
  değişikliği yansımaz.
- `templates/user.html` düz statik HTML/CSS/JS'tir, Jinja değişkeni kullanmaz.
- `templates/admin.html` ve `admin_login.html` Jinja değişkenleri kullanır,
  `routes_admin.py` bunları `render_template()` ile doldurur.
- WAV formatında yaygın/evrensel bir gömülü albüm kapağı standardı
  olmadığı için kapak resmi sadece MP3/FLAC indirmelerine gömülür.
