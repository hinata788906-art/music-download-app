"""IP başına son aramalar (arama kutusunun altında öneri olarak gösterilir)."""
import os
import json

import config

SEARCH_HISTORY_FILE = os.path.join(os.path.dirname(config.LIBRARY_FILE), 'search_history.json')
MAX_HISTORY_PER_IP = 15


def load_search_history():
    if os.path.exists(SEARCH_HISTORY_FILE):
        try:
            with open(SEARCH_HISTORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_search_history(data):
    try:
        with open(SEARCH_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Arama gecmisi kaydetme hatasi: {e}")


search_history = load_search_history()


def add_search(ip, query):
    query = query.strip()
    if not query:
        return
    items = search_history.setdefault(ip, [])
    items[:] = [q for q in items if q.lower() != query.lower()]
    items.insert(0, query)
    del items[MAX_HISTORY_PER_IP:]
    save_search_history(search_history)


def get_history(ip):
    return search_history.get(ip, [])


def clear_history(ip):
    if ip in search_history:
        search_history[ip] = []
        save_search_history(search_history)
