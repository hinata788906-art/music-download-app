"""İndirilen ses dosyalarına albüm kapağını (YouTube thumbnail) gömer.

MP3 için ID3 APIC, FLAC için FLAC Picture bloğu kullanılır — böylece dosya
herhangi bir müzik çalarda (telefon, bilgisayar, araç radyosu) açıldığında
albüm kapağı otomatik görünür. WAV formatında yaygın/evrensel bir gömülü
kapak resmi standardı olmadığı için WAV atlanır (bu format zaten sadece ham
PCM veridir).
"""
import requests

try:
    from mutagen.id3 import ID3, APIC, ID3NoHeaderError
    from mutagen.mp3 import MP3
    from mutagen.flac import FLAC, Picture
    MUTAGEN_AVAILABLE = True
except ImportError:
    MUTAGEN_AVAILABLE = False


def _fetch_thumbnail_bytes(thumbnail_url, timeout=6):
    if not thumbnail_url:
        return None
    try:
        res = requests.get(thumbnail_url, timeout=timeout)
        if res.status_code == 200 and res.content:
            return res.content
    except Exception:
        pass
    return None


def embed_artwork(file_path, fmt, thumbnail_url):
    """Verilen dosyaya kapak resmini gömmeyi dener. Başarısız olursa sessizce
    geçer — kapak gömülemese bile indirme işlemi başarısız sayılmaz."""
    if not MUTAGEN_AVAILABLE or fmt not in ('mp3', 'flac'):
        return False
    image_bytes = _fetch_thumbnail_bytes(thumbnail_url)
    if not image_bytes:
        return False
    try:
        if fmt == 'mp3':
            audio = MP3(file_path, ID3=ID3)
            try:
                audio.add_tags()
            except Exception:
                pass
            audio.tags.add(APIC(
                encoding=3,
                mime='image/jpeg',
                type=3,  # "cover (front)"
                desc='Cover',
                data=image_bytes
            ))
            audio.save()
        elif fmt == 'flac':
            audio = FLAC(file_path)
            pic = Picture()
            pic.type = 3
            pic.mime = 'image/jpeg'
            pic.desc = 'Cover'
            pic.data = image_bytes
            audio.clear_pictures()
            audio.add_picture(pic)
            audio.save()
        return True
    except Exception:
        return False
