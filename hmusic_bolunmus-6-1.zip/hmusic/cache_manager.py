"""Akış önbelleği (CACHE_FOLDER) için otomatik boyut limiti.

Her akış isteğinden sonra çağrılır: önbellek toplam boyutu limiti aşarsa,
en eski erişilen (mtime) dosyalardan başlayarak limitin altına inene kadar
siler. Kullanıcının indirdiği dosyalara (DOWNLOAD_FOLDER) hiç dokunmaz.
"""
import os

import config

DEFAULT_CACHE_LIMIT_MB = 500


def get_cache_limit_bytes():
    mb = config.app_config.get('cache_limit_mb', DEFAULT_CACHE_LIMIT_MB)
    try:
        mb = int(mb)
    except (TypeError, ValueError):
        mb = DEFAULT_CACHE_LIMIT_MB
    return max(50, mb) * 1024 * 1024  # en az 50MB, kazara 0'a kilitlenmeyi önler


def set_cache_limit_mb(mb):
    mb = max(50, int(mb))
    config.app_config['cache_limit_mb'] = mb
    config.save_config(config.app_config)
    return mb


def get_cache_size_bytes():
    total = 0
    try:
        for fname in os.listdir(config.CACHE_FOLDER):
            fpath = os.path.join(config.CACHE_FOLDER, fname)
            if os.path.isfile(fpath):
                total += os.path.getsize(fpath)
    except Exception:
        pass
    return total


def enforce_cache_limit():
    """Önbellek boyutu limiti aşıyorsa en eski dosyalardan silerek limitin
    altına indirir. Kaç bayt silindiğini döner."""
    limit = get_cache_limit_bytes()
    try:
        entries = []
        for fname in os.listdir(config.CACHE_FOLDER):
            fpath = os.path.join(config.CACHE_FOLDER, fname)
            if os.path.isfile(fpath):
                entries.append((fpath, os.path.getsize(fpath), os.path.getmtime(fpath)))
    except Exception:
        return 0

    total = sum(size for _, size, _ in entries)
    if total <= limit:
        return 0

    entries.sort(key=lambda e: e[2])  # en eski erişilen (mtime) önce
    freed = 0
    for fpath, size, _ in entries:
        if total <= limit:
            break
        try:
            os.remove(fpath)
            total -= size
            freed += size
        except Exception:
            continue
    return freed
