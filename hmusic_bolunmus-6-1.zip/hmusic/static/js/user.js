    const audioPlayer = document.getElementById('audioPlayer');
    const audioPlayerAlt = document.getElementById('audioPlayerAlt');
    let activeAudioPlayer = audioPlayer;
    let standbyAudioPlayer = audioPlayerAlt;
    let crossfadeSeconds = parseInt(localStorage.getItem('hmusic_crossfade') || '0', 10);
    let crossfadeInProgress = false;
    let downloadedData = [];
    let artistViewItems = [];
    const playerPanel = document.getElementById('playerPanel');
    const playerCover = document.getElementById('playerCover');
    const playerTitle = document.getElementById('playerTitle');
    const playerTitleMask = document.getElementById('playerTitleMask');
    const playerStatus = document.getElementById('playerStatus');
    function setPlayerTitle(text) {
        playerTitle.innerText = text;
        playerTitleMask.classList.remove('marquee');
        playerTitleMask.style.removeProperty('--marquee-distance');
        playerTitleMask.style.removeProperty('--marquee-duration');
        requestAnimationFrame(() => {
            const overflow = playerTitle.scrollWidth - playerTitleMask.clientWidth;
            if (overflow > 8) {
                playerTitleMask.style.setProperty('--marquee-distance', `-${overflow + 4}px`);
                playerTitleMask.style.setProperty('--marquee-duration', `${Math.max(6, overflow / 22)}s`);
                playerTitleMask.classList.add('marquee');
            }
        });
    }
    const playIcon = document.getElementById('playIcon');
    const pauseIcon = document.getElementById('pauseIcon');
    const seekBar = document.getElementById('seekBar');
    const currentTimeEl = document.getElementById('currentTime');
    const durationTimeEl = document.getElementById('durationTime');
    let currentBtn = null;
    let searchResults = [];
    let favoritesData = [];
    let favoriteIds = new Set();
    let playlistsData = [];
    let activePlaylistId = null;
    let activePlaylistSongs = [];
    let activeQueue = [];
    let activeQueueType = null;
    let activeQueueIndex = -1;
    let autoAdvance = true;
    let actionSheetContext = null;

    // ---------- Dil / Language ----------
    const LANG_DICT = {
        header_subtitle: { tr: 'Ağsız Müzik ve Video Deneyimi', en: 'Seamless Music & Video Experience' },
        settings_eq: { tr: 'Ses Efektleri', en: 'Sound Effects' },
        settings_storage: { tr: 'İndirme Konumu', en: 'Download Location' },
        settings_lang: { tr: 'Dil', en: 'Language' },
        storage_modal_title: { tr: 'İndirme Konumu', en: 'Download Location' },
        storage_modal_sub: { tr: 'İndirilen müziklerin kaydedileceği depolama alanını seçin', en: 'Choose where downloaded music will be saved' },
        eq_modal_title: { tr: 'Ses Efektleri', en: 'Sound Effects' },
        eq_modal_sub: { tr: 'Ekolayzır ve 8D ses deneyimini kişiselleştirin', en: 'Customize your equalizer and 8D sound experience' },
        eq_active: { tr: 'Ekolayzır Aktif', en: 'Equalizer Active' },
        eightd_label: { tr: '8D Ses Efekti', en: '8D Sound Effect' },
        rotation_speed: { tr: 'Dönüş Hızı', en: 'Rotation Speed' },
        surround_label: { tr: 'Sinema Ses (Surround)', en: 'Cinema Sound (Surround)' },
        effect_strength: { tr: 'Etki Gücü', en: 'Effect Strength' },
        tab_search: { tr: 'Ara', en: 'Search' },
        tab_favorites: { tr: 'Favoriler', en: 'Favorites' },
        tab_playlists: { tr: 'Listelerim', en: 'My Playlists' },
        search_placeholder: { tr: 'Şarkı veya sanatçı ara...', en: 'Search for a song or artist...' },
        search_btn: { tr: 'Ara', en: 'Search' },
        new_playlist_btn: { tr: '+ Yeni Çalma Listesi', en: '+ New Playlist' },
        add_to_playlist: { tr: 'Çalma Listesine Ekle', en: 'Add to Playlist' },
        download_mp3: { tr: 'MP3 İndir', en: 'Download MP3' },
        download_mp4: { tr: 'MP4 İndir', en: 'Download MP4' },
        remove_from_playlist: { tr: 'Listeden Çıkar', en: 'Remove from Playlist' },
        new_playlist_placeholder: { tr: 'Yeni liste adı...', en: 'New playlist name...' },
        create_btn: { tr: 'Oluştur', en: 'Create' },
        play_all: { tr: '▶ Tümünü Çal', en: '▶ Play All' },
        delete_playlist: { tr: 'Listeyi Sil', en: 'Delete Playlist' },
        playlist_default_name: { tr: 'Liste', en: 'Playlist' },
        song_default_title: { tr: 'Şarkı', en: 'Song' },
        player_title_default: { tr: 'Şarkı Adı', en: 'Song Title' },
        preparing: { tr: 'Hazırlanıyor...', en: 'Preparing...' },
        searching: { tr: 'Aranıyor...', en: 'Searching...' },
        popular_songs: { tr: 'Popüler Şarkılar', en: 'Popular Songs' },
        loading_popular: { tr: 'Popüler şarkılar yükleniyor...', en: 'Loading popular songs...' },
        access_denied: { tr: 'Erişiminiz Engellendi!', en: 'Your access has been blocked!' },
        no_results: { tr: 'Sonuç bulunamadı.', en: 'No results found.' },
        error_occurred: { tr: 'Bir hata oluştu!', en: 'An error occurred!' },
        generic_error_dot: { tr: 'Bir hata oluştu.', en: 'An error occurred.' },
        no_playlists_yet: { tr: 'Henüz çalma listeniz yok.', en: "You don't have any playlists yet." },
        no_favorites_yet: { tr: 'Henüz favori şarkınız yok.', en: "You don't have any favorite songs yet." },
        no_songs_in_playlist: { tr: 'Bu listede henüz şarkı yok.', en: 'There are no songs in this playlist yet.' },
        confirm_delete_playlist: { tr: 'Bu çalma listesini silmek istediğinize emin misiniz?', en: 'Are you sure you want to delete this playlist?' },
        prompt_new_playlist: { tr: 'Yeni çalma listesi adı:', en: 'New playlist name:' },
        no_playlists_create_below: { tr: 'Henüz çalma listeniz yok, aşağıdan oluşturun.', en: "You don't have any playlists yet, create one below." },
        adding: { tr: 'Ekleniyor...', en: 'Adding...' },
        add_failed: { tr: 'Eklenemedi.', en: 'Could not add.' },
        already_in_playlist: { tr: 'Bu şarkı zaten listede.', en: 'This song is already in the playlist.' },
        added_to_playlist: { tr: 'Listeye eklendi ✓', en: 'Added to playlist ✓' },
        playlist_created_now_tap: { tr: 'Liste oluşturuldu, şimdi şarkıya dokunun.', en: 'Playlist created, now tap the song.' },
        end_of_list: { tr: 'Liste sonu', en: 'End of list' },
        playing: { tr: 'Çalınıyor', en: 'Playing' },
        paused: { tr: 'Duraklatıldı', en: 'Paused' },
        song_count_suffix: { tr: 'şarkı', en: 'songs' },
        loading: { tr: 'Yükleniyor...', en: 'Loading...' },
        storage_load_failed: { tr: 'Depolama bilgisi alınamadı.', en: 'Could not retrieve storage info.' },
        storage_none_found: { tr: 'Depolama bulunamadı.', en: 'No storage found.' },
        saving: { tr: 'Kaydediliyor...', en: 'Saving...' },
        change_failed: { tr: 'Değiştirilemedi.', en: 'Could not be changed.' },
        saved_prefix: { tr: 'Kaydedildi: ', en: 'Saved: ' },
        preset_flat: { tr: 'Düz', en: 'Flat' },
        preset_bass: { tr: 'Bas', en: 'Bass' },
        preset_vocal: { tr: 'Vokal', en: 'Vocal' },
        preset_treble: { tr: 'Tiz', en: 'Treble' },
        settings_crossfade: { tr: 'Çapraz Geçiş', en: 'Crossfade' },
        settings_cache: { tr: 'Önbelleği Temizle', en: 'Clear Cache' },
        settings_offline: { tr: 'Çevrimdışı Mod', en: 'Offline Mode' },
        settings_theme: { tr: 'Tema', en: 'Theme' },
        settings_canvas: { tr: 'Hareketli Kapak', en: 'Animated Cover' },
        settings_lock: { tr: 'Kilit Ekranı Kontrolleri', en: 'Lock Screen Controls' },
        crossfade_modal_title: { tr: 'Çapraz Geçiş', en: 'Crossfade' },
        crossfade_modal_sub: { tr: 'Şarkılar arasında sessizlik olmadan yumuşak geçiş süresi', en: 'Smooth transition time between songs, with no silence' },
        crossfade_off: { tr: 'Kapalı', en: 'Off' },
        cache_modal_title: { tr: 'Önbelleği Temizle', en: 'Clear Cache' },
        cache_modal_sub: { tr: 'Dinlemek için geçici olarak indirilen dosyaları sil', en: 'Delete files temporarily downloaded for streaming' },
        cache_size_label: { tr: 'önbellek boyutu', en: 'cache size' },
        theme_modal_title: { tr: 'Tema', en: 'Theme' },
        theme_system: { tr: 'Cihaz', en: 'System' },
        theme_dark: { tr: 'Koyu', en: 'Dark' },
        theme_light: { tr: 'Açık', en: 'Light' },
        tab_downloaded: { tr: 'İndirilenler', en: 'Downloads' },
        offline_hint: { tr: 'Çevrimdışı moddasınız, sadece cihaza indirilmiş şarkılar çalınabilir.', en: "You're in offline mode, only songs downloaded to this device can play." },
        offline_blocked: { tr: 'Bu şarkı cihazınıza indirilmemiş. Çevrimdışı moddayken sadece indirilen şarkılar çalınabilir.', en: 'This song is not downloaded to your device. Only downloaded songs can play in offline mode.' },
        no_downloads_yet: { tr: 'Henüz indirilmiş şarkı yok.', en: 'No downloaded songs yet.' },
        confirm_delete_download: { tr: 'Bu indirilen şarkıyı cihazdan silmek istediğinize emin misiniz?', en: 'Are you sure you want to delete this downloaded song from your device?' },
        settings_audio_quality: { tr: 'Ses Kalitesi', en: 'Audio Quality' },
        audio_quality_modal_title: { tr: 'Ses Kalitesi', en: 'Audio Quality' },
        audio_quality_modal_sub: { tr: "İndirilen dosyaların formatını, örnekleme hızını ve bit derinliğini seç", en: 'Choose the format, sample rate and bit depth of downloaded files' },
        audio_format_label: { tr: 'Format', en: 'Format' },
        audio_samplerate_label: { tr: 'Örnekleme Hızı', en: 'Sample Rate' },
        audio_bitdepth_label: { tr: 'Bit Derinliği', en: 'Bit Depth' },
        audio_quality_note: { tr: 'Not: Kaynak YouTube\'un kendi (kayıplı) ses akışı olduğu için bu ayarlar kaydı "yeniden yaratmaz" — sadece indirilen dosyanın MP3\'e ek bir kayıplı sıkıştırma turundan geçmesini önler ve dosyayı seçtiğin format/örnekleme hızında teslim eder.', en: "Note: Since the source is YouTube's own (lossy) audio stream, these settings don't \"recreate\" the original recording — they just avoid an extra lossy re-encoding pass into MP3 and deliver the file in your chosen format/sample rate." },
        lyrics_title: { tr: 'Şarkı Sözleri', en: 'Lyrics' },
        lyrics_no_song: { tr: 'Önce bir şarkı çal.', en: 'Play a song first.' },
        lyrics_not_found: { tr: 'Bu şarkı için söz bulunamadı.', en: 'No lyrics found for this song.' },
        lyrics_source_note: { tr: 'Sözler lyrics.ovh üzerinden gösterilmektedir, doğruluğu garanti edilmez.', en: 'Lyrics are shown via lyrics.ovh and accuracy is not guaranteed.' },
        bass_boost_label: { tr: 'Bass Boost', en: 'Bass Boost' },
        treble_boost_label: { tr: 'Treble Boost', en: 'Treble Boost' },
        loudness_label: { tr: 'Loudness (Ses Dengeleme)', en: 'Loudness (Volume Leveling)' },
        shuffle_label: { tr: 'Karışık Çal', en: 'Shuffle' },
        sleep_timer_label: { tr: 'Uyku Zamanlayıcısı', en: 'Sleep Timer' },
        sleep_timer_modal_title: { tr: 'Uyku Zamanlayıcısı', en: 'Sleep Timer' },
        sleep_timer_modal_sub: { tr: 'Belirtilen süre sonunda müzik yumuşakça duracak', en: 'Music will fade out and stop after the selected time' },
        sleep_timer_off: { tr: 'Kapalı', en: 'Off' },
        sleep_timer_active_prefix: { tr: 'Kalan süre: ', en: 'Time left: ' },
        cache_limit_label: { tr: 'Önbellek Limiti', en: 'Cache Limit' },
        search_history_label: { tr: 'Son Aramalar', en: 'Recent Searches' },
        search_history_clear: { tr: 'Temizle', en: 'Clear' },
        artist_view_back: { tr: '← Geri', en: '← Back' },
        artist_view_empty: { tr: 'Bu sanatçıya ait başka şarkı bulunamadı.', en: 'No other songs found for this artist.' },
        download_progress_starting: { tr: 'Başlatılıyor...', en: 'Starting...' },
        download_progress_downloading: { tr: 'İndiriliyor', en: 'Downloading' },
        download_progress_processing: { tr: 'İşleniyor...', en: 'Processing...' },
        download_progress_done: { tr: 'Tamamlandı ✓', en: 'Done ✓' },
        download_progress_error: { tr: 'İndirme başarısız', en: 'Download failed' },
        lyrics_copy: { tr: 'Kopyala', en: 'Copy' },
        lyrics_copied: { tr: 'Kopyalandı ✓', en: 'Copied ✓' }
    };
    let currentLang = localStorage.getItem('hmusic_lang') || 'tr';
    function t(key) {
        const entry = LANG_DICT[key];
        if (!entry) return key;
        return entry[currentLang] || entry.tr;
    }

    function applyStaticTexts() {
        document.getElementById('headerSubtitle').textContent = t('header_subtitle');
        document.getElementById('settingsEqLabel').textContent = t('settings_eq');
        document.getElementById('settingsStorageLabel').textContent = t('settings_storage');
        document.getElementById('settingsLangLabel').textContent = t('settings_lang');
        document.getElementById('storageModalTitle').textContent = t('storage_modal_title');
        document.getElementById('storageModalSub').textContent = t('storage_modal_sub');
        document.getElementById('eqModalTitle').textContent = t('eq_modal_title');
        document.getElementById('eqModalSub').textContent = t('eq_modal_sub');
        document.getElementById('eqActiveLabel').textContent = t('eq_active');
        document.getElementById('eightDLabel').textContent = t('eightd_label');
        document.getElementById('rotationSpeedLabel').textContent = t('rotation_speed');
        document.getElementById('surroundLabel').textContent = t('surround_label');
        document.getElementById('effectStrengthLabel').textContent = t('effect_strength');
        document.getElementById('tabSearchLabel').textContent = t('tab_search');
        document.getElementById('tabFavoritesLabel').textContent = t('tab_favorites');
        document.getElementById('tabPlaylistsLabel').textContent = t('tab_playlists');
        document.getElementById('searchInput').placeholder = t('search_placeholder');
        document.getElementById('searchBtn').textContent = t('search_btn');
        document.getElementById('newPlaylistBtn').textContent = t('new_playlist_btn');
        document.getElementById('actionSheetAddLabel').textContent = t('add_to_playlist');
        document.getElementById('actionSheetMp3Label').textContent = t('download_mp3').replace('MP3', audioFormat.toUpperCase());
        document.getElementById('actionSheetMp4Label').textContent = t('download_mp4');
        document.getElementById('actionSheetRemoveLabel').textContent = t('remove_from_playlist');
        document.getElementById('addToPlaylistTitle').textContent = t('add_to_playlist');
        document.getElementById('newPlaylistNameInput').placeholder = t('new_playlist_placeholder');
        document.getElementById('createPlaylistBtn').textContent = t('create_btn');
        document.getElementById('playAllBtn').textContent = t('play_all');
        document.getElementById('deletePlaylistBtn').textContent = t('delete_playlist');
        document.getElementById('settingsCrossfadeLabel').textContent = t('settings_crossfade');
        document.getElementById('settingsCacheLabel').textContent = t('settings_cache');
        document.getElementById('settingsOfflineLabel').textContent = t('settings_offline');
        document.getElementById('settingsThemeLabel').textContent = t('settings_theme');
        document.getElementById('settingsCanvasLabel').textContent = t('settings_canvas');
        document.getElementById('settingsLockLabel').textContent = t('settings_lock');
        document.getElementById('crossfadeModalTitle').textContent = t('crossfade_modal_title');
        document.getElementById('crossfadeModalSub').textContent = t('crossfade_modal_sub');
        document.getElementById('crossfadeOffLabel').textContent = t('crossfade_off');
        document.getElementById('crossfadeValueLabel').textContent = crossfadeSeconds === 0 ? t('crossfade_off') : crossfadeSeconds + 's';
        document.getElementById('cacheModalTitle').textContent = t('cache_modal_title');
        document.getElementById('cacheModalSub').textContent = t('cache_modal_sub');
        document.getElementById('cacheSizeLabel').textContent = t('cache_size_label');
        document.getElementById('clearCacheBtn').textContent = t('settings_cache');
        document.getElementById('themeModalTitle').textContent = t('theme_modal_title');
        document.getElementById('themeBtnSystem').textContent = t('theme_system');
        document.getElementById('themeBtnDark').textContent = t('theme_dark');
        document.getElementById('themeBtnLight').textContent = t('theme_light');
        document.getElementById('tabDownloadedLabel').textContent = t('tab_downloaded');
        document.getElementById('settingsAudioQualityLabel').textContent = t('settings_audio_quality');
        document.getElementById('audioQualityModalTitle').textContent = t('audio_quality_modal_title');
        document.getElementById('audioQualityModalSub').textContent = t('audio_quality_modal_sub');
        document.getElementById('audioFormatLabel').textContent = t('audio_format_label');
        document.getElementById('audioSampleRateLabel').textContent = t('audio_samplerate_label');
        document.getElementById('audioBitDepthLabel').textContent = t('audio_bitdepth_label');
        document.getElementById('audioQualityNote').textContent = t('audio_quality_note');
        document.getElementById('lyricsModalTitle').textContent = t('lyrics_title');
        document.getElementById('lyricsSourceNote').textContent = t('lyrics_source_note');
        document.getElementById('bassBoostLabel').textContent = t('bass_boost_label');
        document.getElementById('trebleBoostLabel').textContent = t('treble_boost_label');
        document.getElementById('loudnessLabel').textContent = t('loudness_label');
        document.getElementById('settingsSleepTimerLabel').textContent = t('sleep_timer_label');
        document.getElementById('sleepTimerModalTitle').textContent = t('sleep_timer_modal_title');
        document.getElementById('sleepTimerModalSub').textContent = t('sleep_timer_modal_sub');
        document.getElementById('cacheLimitLabel').textContent = t('cache_limit_label');
        document.getElementById('searchHistoryClearBtn').textContent = t('search_history_clear');
        document.getElementById('searchHistoryLabel').textContent = t('search_history_label');
        document.getElementById('artistViewBackBtn').textContent = t('artist_view_back');
        document.getElementById('popularHeading').textContent = t('popular_songs');
        document.getElementById('lyricsCopyBtn').textContent = t('lyrics_copy');
        applyOfflineModeUI();
        document.documentElement.lang = currentLang;
        document.getElementById('langBtnTr').classList.toggle('active', currentLang === 'tr');
        document.getElementById('langBtnEn').classList.toggle('active', currentLang === 'en');
    }

    function refreshDynamicTexts() {
        if (document.getElementById('searchTabContent').classList.contains('active')) {
            renderCardList(document.getElementById('resultsList'), searchResults, 'search', t('no_results'));
        }
        if (document.getElementById('favoritesTabContent').classList.contains('active')) {
            renderCardList(document.getElementById('favoritesList'), favoritesData, 'favorites', t('no_favorites_yet'));
        }
        if (document.getElementById('playlistsTabContent').classList.contains('active')) {
            renderPlaylistGrid();
        }
        if (document.getElementById('downloadedTabContent').classList.contains('active')) {
            renderCardList(document.getElementById('downloadedList'), downloadedData, 'downloaded', t('no_downloads_yet'));
        }
    }

    function setLanguage(lang) {
        currentLang = lang;
        localStorage.setItem('hmusic_lang', lang);
        applyStaticTexts();
        refreshDynamicTexts();
        if (!document.getElementById('searchInput').value.trim()) {
            loadPopular();
        }
    }

    function getQueueArray(queueType) {
        if (queueType === 'search') return searchResults;
        if (queueType === 'favorites') return favoritesData;
        if (queueType === 'playlist') return activePlaylistSongs;
        if (queueType === 'downloaded') return downloadedData;
        if (queueType === 'artistview') return artistViewItems;
        return [];
    }

    // ---------- Şarkı kartı üretimi (arama / favoriler / çalma listesi / indirilenler ortak) ----------
    function songCardHTML(item, queueType, index) {
        if (queueType === 'downloaded') {
            return `
                <img src="${item.thumbnail || ''}" alt="thumb" onerror="this.style.visibility='hidden'">
                <div class="card-info">
                    <div class="card-title">${item.title}</div>
                    <div class="card-artist">HMusic Stream</div>
                </div>
                <div class="action-btns">
                    <button class="icon-btn btn-play" onclick="playSong(this, 'downloaded', ${index})">
                        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </button>
                    <button class="icon-btn btn-more" onclick="deleteLocalDownload(${index})">
                        <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                    </button>
                </div>
            `;
        }
        const isFav = favoriteIds.has(item.id);
        return `
            <img src="${item.thumbnail}" alt="thumb" loading="lazy">
            <div class="card-info">
                <div class="card-title">${item.title}</div>
                <div class="card-artist">HMusic Stream</div>
            </div>
            <div class="action-btns">
                <button class="icon-btn btn-play" onclick="playSong(this, '${queueType}', ${index})">
                    <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                </button>
                <button class="icon-btn btn-heart${isFav ? ' active' : ''}" onclick="toggleFavoriteFromCard(this, '${queueType}', ${index})">
                    <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                </button>
                <button class="icon-btn btn-more" onclick="openActionSheet('${queueType}', ${index})">
                    <svg viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                </button>
            </div>
        `;
    }

    function renderCardList(container, list, queueType, emptyMessage) {
        container.innerHTML = '';
        if (!list.length) {
            container.innerHTML = `<p class="empty-hint">${emptyMessage}</p>`;
            return;
        }
        list.forEach((item, index) => {
            const card = document.createElement('div');
            card.className = 'card';
            card.style.animationDelay = (index * 0.04) + 's';
            card.innerHTML = songCardHTML(item, queueType, index);
            container.appendChild(card);
        });
    }

    // ---------- Popüler ----------
    async function loadPopular() {
        if (offlineMode) return;
        const resultsList = document.getElementById('resultsList');
        const heading = document.getElementById('popularHeading');
        heading.style.display = 'none';
        resultsList.innerHTML = `<p style="text-align:center; color:#6b7280; margin-top:20px;">${t('loading_popular')}</p>`;
        try {
            const res = await fetch(`/api/popular?lang=${currentLang}`);
            const data = await res.json();
            if (!data || data.length === 0 || data.error) {
                resultsList.innerHTML = '';
                return;
            }
            searchResults = data;
            heading.textContent = t('popular_songs');
            heading.style.display = 'block';
            renderCardList(resultsList, searchResults, 'search', t('no_results'));
        } catch (err) {
            resultsList.innerHTML = '';
        }
    }

    // ---------- Arama ----------
    async function searchMusic(overrideQuery) {
        const inputEl = document.getElementById('searchInput');
        const query = (overrideQuery !== undefined ? overrideQuery : inputEl.value).trim();
        if (!query) return;
        if (liveSearchTimer) clearTimeout(liveSearchTimer);
        liveSearchToken++;
        inputEl.value = query;
        hideSearchHistory();
        const resultsList = document.getElementById('resultsList');
        const heading = document.getElementById('popularHeading');
        heading.style.display = 'none';
        resultsList.innerHTML = `<p style="text-align:center; color:#6b7280; margin-top:20px;">${t('searching')}</p>`;
        try {
            const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
            if (res.status === 403) {
                resultsList.innerHTML = `<p style="text-align:center; color:#ef4444; margin-top:20px;">${t('access_denied')}</p>`;
                return;
            }
            const data = await res.json();
            if (!data || data.length === 0 || data.error) {
                resultsList.innerHTML = `<p style="text-align:center; color:#6b7280; margin-top:20px;">${t('no_results')}</p>`;
                return;
            }
            searchResults = data;
            renderCardList(resultsList, searchResults, 'search', t('no_results'));
        } catch (err) {
            resultsList.innerHTML = `<p style="text-align:center; color:#ef4444; margin-top:20px;">${t('error_occurred')}</p>`;
        }
    }

    // ---------- Arama Geçmişi ----------
    async function showSearchHistory() {
        if (document.getElementById('searchInput').value.trim()) return;
        try {
            const res = await fetch('/api/search-history');
            const data = await res.json();
            const items = data.items || [];
            const box = document.getElementById('searchHistoryBox');
            const chips = document.getElementById('searchHistoryChips');
            if (!items.length) {
                box.style.display = 'none';
                return;
            }
            chips.innerHTML = '';
            items.forEach(q => {
                const chip = document.createElement('button');
                chip.type = 'button';
                chip.className = 'search-history-chip';
                chip.innerText = q;
                chip.onclick = () => searchMusic(q);
                chips.appendChild(chip);
            });
            box.style.display = 'block';
        } catch (err) { /* sessizce geç */ }
    }
    function hideSearchHistory() {
        document.getElementById('searchHistoryBox').style.display = 'none';
    }
    let liveSearchTimer = null;
    let liveSearchToken = 0;
    function onSearchInputChange() {
        const query = document.getElementById('searchInput').value.trim();
        if (liveSearchTimer) clearTimeout(liveSearchTimer);
        if (query) {
            hideSearchHistory();
            if (query.length < 2) return;
            liveSearchTimer = setTimeout(() => liveSearchMusic(query), 400);
        } else {
            showSearchHistory();
            loadPopular();
        }
    }
    async function liveSearchMusic(query) {
        const myToken = ++liveSearchToken;
        const resultsList = document.getElementById('resultsList');
        const heading = document.getElementById('popularHeading');
        heading.style.display = 'none';
        resultsList.innerHTML = `<p style="text-align:center; color:#6b7280; margin-top:20px;">${t('searching')}</p>`;
        try {
            const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
            if (myToken !== liveSearchToken) return; // daha yeni bir arama başladı, bu sonucu yoksay
            if (res.status === 403) {
                resultsList.innerHTML = `<p style="text-align:center; color:#ef4444; margin-top:20px;">${t('access_denied')}</p>`;
                return;
            }
            const data = await res.json();
            if (myToken !== liveSearchToken) return;
            if (!data || data.length === 0 || data.error) {
                resultsList.innerHTML = `<p style="text-align:center; color:#6b7280; margin-top:20px;">${t('no_results')}</p>`;
                return;
            }
            searchResults = data;
            renderCardList(resultsList, searchResults, 'search', t('no_results'));
        } catch (err) {
            if (myToken !== liveSearchToken) return;
            resultsList.innerHTML = `<p style="text-align:center; color:#ef4444; margin-top:20px;">${t('error_occurred')}</p>`;
        }
    }
    async function clearSearchHistoryHandler() {
        try {
            await fetch('/api/search-history', { method: 'DELETE' });
            hideSearchHistory();
        } catch (err) { /* sessizce geç */ }
    }

    // ---------- Sekmeler ----------
    const tabOrder = ['search', 'favorites', 'downloaded', 'playlists'];
    function switchTab(tab) {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById('tab' + tab.charAt(0).toUpperCase() + tab.slice(1) + 'Btn').classList.add('active');
        document.getElementById(tab + 'TabContent').classList.add('active');
        if (tab === 'favorites') loadFavoritesTab();
        if (tab === 'playlists') loadPlaylistsTab();
        if (tab === 'downloaded') loadDownloadedTab();
    }

    // ---------- Sekmeler arası kaydırma (swipe) ----------
    (function initTabSwipe() {
        const container = document.getElementById('tabSwipeContainer');
        if (!container) return;
        let startX = 0, startY = 0, tracking = false, decided = false, horizontal = false;
        const SWIPE_THRESHOLD = 50;

        container.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
            tracking = true;
            decided = false;
            horizontal = false;
        }, { passive: true });

        container.addEventListener('touchmove', (e) => {
            if (!tracking || e.touches.length !== 1) return;
            const dx = e.touches[0].clientX - startX;
            const dy = e.touches[0].clientY - startY;
            if (!decided && (Math.abs(dx) > 12 || Math.abs(dy) > 12)) {
                decided = true;
                horizontal = Math.abs(dx) > Math.abs(dy);
            }
            if (decided && horizontal) {
                e.preventDefault();
            }
        }, { passive: false });

        container.addEventListener('touchend', (e) => {
            if (!tracking) return;
            tracking = false;
            if (!horizontal) return;
            const dx = e.changedTouches[0].clientX - startX;
            if (Math.abs(dx) < SWIPE_THRESHOLD) return;
            const currentTab = document.querySelector('.tab-content.active').id.replace('TabContent', '');
            const idx = tabOrder.indexOf(currentTab);
            if (idx === -1) return;
            if (dx < 0 && idx < tabOrder.length - 1) {
                switchTab(tabOrder[idx + 1]); // sola kaydırma -> sonraki sekme
            } else if (dx > 0 && idx > 0) {
                switchTab(tabOrder[idx - 1]); // sağa kaydırma -> önceki sekme
            }
        });

        container.addEventListener('touchcancel', () => { tracking = false; });
    })();

    async function loadLibrary() {
        try {
            const res = await fetch('/api/library');
            const data = await res.json();
            favoritesData = data.favorites || [];
            favoriteIds = new Set(favoritesData.map(s => s.id));
            playlistsData = data.playlists || [];
        } catch (err) { /* sessizce geç */ }
    }

    async function loadFavoritesTab() {
        await loadLibrary();
        renderCardList(document.getElementById('favoritesList'), favoritesData, 'favorites', t('no_favorites_yet'));
    }

    async function loadPlaylistsTab() {
        await loadLibrary();
        renderPlaylistGrid();
    }

    function renderPlaylistGrid() {
        const grid = document.getElementById('playlistGrid');
        grid.innerHTML = '';
        if (!playlistsData.length) {
            grid.innerHTML = `<p class="empty-hint">${t('no_playlists_yet')}</p>`;
            return;
        }
        playlistsData.forEach((pl, i) => {
            const card = document.createElement('div');
            card.className = 'playlist-card';
            card.style.animationDelay = (i * 0.04) + 's';
            card.onclick = () => openPlaylistDetail(pl.id);
            card.innerHTML = `
                <div class="playlist-card-icon">
                    <svg viewBox="0 0 24 24"><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"/></svg>
                </div>
                <div class="playlist-card-info">
                    <div class="playlist-card-name">${pl.name}</div>
                    <div class="playlist-card-count">${pl.count} ${t('song_count_suffix')}</div>
                </div>
            `;
            grid.appendChild(card);
        });
    }

    // ---------- Favoriler ----------
    async function toggleFavoriteFromCard(btn, queueType, index) {
        const item = getQueueArray(queueType)[index];
        if (!item) return;
        btn.classList.add('pop');
        setTimeout(() => btn.classList.remove('pop'), 400);
        try {
            const res = await fetch('/api/favorites/toggle', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(item)
            });
            const data = await res.json();
            if (!res.ok || data.error) return;
            favoritesData = data.favorites || [];
            favoriteIds = new Set(favoritesData.map(s => s.id));
            btn.classList.toggle('active', data.is_favorite);
            if (queueType === 'favorites') {
                renderCardList(document.getElementById('favoritesList'), favoritesData, 'favorites', t('no_favorites_yet'));
            }
        } catch (err) { /* sessizce geç */ }
    }

    // ---------- Çalma Listeleri ----------
    function openCreatePlaylistPrompt() {
        const name = prompt(t('prompt_new_playlist'));
        if (!name || !name.trim()) return;
        createPlaylist(name.trim());
    }

    async function createPlaylist(name) {
        try {
            const res = await fetch('/api/playlists', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const data = await res.json();
            if (!res.ok || data.error) return null;
            playlistsData.push({ id: data.id, name: data.name, count: 0 });
            renderPlaylistGrid();
            return data.id;
        } catch (err) { return null; }
    }

    async function openPlaylistDetail(playlistId) {
        try {
            const res = await fetch(`/api/playlists/${playlistId}`);
            const data = await res.json();
            if (!res.ok || data.error) return;
            activePlaylistId = playlistId;
            activePlaylistSongs = data.songs || [];
            document.getElementById('playlistDetailName').innerText = data.name;
            renderCardList(document.getElementById('playlistDetailSongs'), activePlaylistSongs, 'playlist', t('no_songs_in_playlist'));
            document.getElementById('playlistDetailOverlay').classList.add('active');
        } catch (err) { /* sessizce geç */ }
    }

    function closePlaylistDetail() {
        document.getElementById('playlistDetailOverlay').classList.remove('active');
    }

    function playPlaylistFromStart() {
        if (!activePlaylistSongs.length) return;
        playSong(null, 'playlist', 0);
    }

    async function deleteCurrentPlaylist() {
        if (!activePlaylistId) return;
        if (!confirm(t('confirm_delete_playlist'))) return;
        try {
            await fetch(`/api/playlists/${activePlaylistId}`, { method: 'DELETE' });
            playlistsData = playlistsData.filter(p => p.id !== activePlaylistId);
            renderPlaylistGrid();
            closePlaylistDetail();
        } catch (err) { /* sessizce geç */ }
    }

    // ---------- Alt sayfa (action sheet) ----------
    function openActionSheet(queueType, index) {
        const item = getQueueArray(queueType)[index];
        if (!item) return;
        actionSheetContext = { item, queueType, index };
        document.getElementById('actionSheetTitle').innerText = item.title;
        document.getElementById('actionSheetRemoveFromPlaylist').style.display = queueType === 'playlist' ? 'flex' : 'none';
        document.getElementById('actionSheetOverlay').classList.add('active');
    }

    function closeActionSheet() {
        document.getElementById('actionSheetOverlay').classList.remove('active');
    }

    function showDownloadToast(title) {
        document.getElementById('downloadToastTitle').innerText = title;
        document.getElementById('downloadToastFill').style.width = '0%';
        document.getElementById('downloadToastStatus').innerText = t('download_progress_starting');
        document.getElementById('downloadToast').classList.add('active');
    }
    function updateDownloadToast(percent, statusText) {
        if (percent != null) document.getElementById('downloadToastFill').style.width = Math.min(100, percent) + '%';
        document.getElementById('downloadToastStatus').innerText = statusText;
    }
    function hideDownloadToastLater(delayMs) {
        setTimeout(() => document.getElementById('downloadToast').classList.remove('active'), delayMs);
    }

    async function pollDownloadJob(jobId) {
        const maxAttempts = 600; // ~10 dakika (1sn aralıkla)
        for (let i = 0; i < maxAttempts; i++) {
            let data;
            try {
                const res = await fetch(`/api/download/progress/${jobId}`);
                data = await res.json();
            } catch (err) {
                updateDownloadToast(null, t('error_occurred'));
                hideDownloadToastLater(3000);
                return;
            }
            if (data.status === 'downloading') {
                updateDownloadToast(data.percent, `${t('download_progress_downloading')} ${data.percent != null ? data.percent + '%' : ''}`);
            } else if (data.status === 'processing') {
                updateDownloadToast(95, t('download_progress_processing'));
            } else if (data.status === 'done') {
                updateDownloadToast(100, t('download_progress_done'));
                window.location.href = `/api/download/file/${jobId}`;
                hideDownloadToastLater(2500);
                return;
            } else if (data.status === 'error') {
                updateDownloadToast(null, t('download_progress_error'));
                hideDownloadToastLater(3500);
                return;
            }
            await new Promise(r => setTimeout(r, 1000));
        }
    }

    async function actionSheetDownload(type) {
        if (!actionSheetContext) return;
        const item = actionSheetContext.item;
        closeActionSheet();
        showDownloadToast(item.title || '');
        try {
            if (type === 'mp4') {
                const res = await fetch('/api/download/start-video', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ url: item.url })
                });
                const data = await res.json();
                if (!data.job_id) throw new Error('no job');
                pollDownloadJob(data.job_id);
                return;
            }
            const res = await fetch('/api/download/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    url: item.url,
                    format: audioFormat,
                    samplerate: audioSampleRate,
                    bitdepth: audioBitDepth
                })
            });
            const data = await res.json();
            if (!data.job_id) throw new Error('no job');
            pollDownloadJob(data.job_id);
        } catch (err) {
            updateDownloadToast(null, t('download_progress_error'));
            hideDownloadToastLater(3000);
        }
    }

    async function actionSheetRemoveFromPlaylist() {
        if (!actionSheetContext || !activePlaylistId) return;
        const item = actionSheetContext.item;
        closeActionSheet();
        try {
            const res = await fetch(`/api/playlists/${activePlaylistId}/songs/${encodeURIComponent(item.id)}`, { method: 'DELETE' });
            const data = await res.json();
            if (!res.ok || data.error) return;
            activePlaylistSongs = data.songs || [];
            renderCardList(document.getElementById('playlistDetailSongs'), activePlaylistSongs, 'playlist', t('no_songs_in_playlist'));
            const pl = playlistsData.find(p => p.id === activePlaylistId);
            if (pl) pl.count = activePlaylistSongs.length;
        } catch (err) { /* sessizce geç */ }
    }

    // ---------- Çalma listesine ekleme seçici ----------
    async function actionSheetAddToPlaylist() {
        closeActionSheet();
        await loadLibrary();
        renderAddToPlaylistList();
        document.getElementById('addToPlaylistStatus').innerText = '';
        document.getElementById('addToPlaylistOverlay').classList.add('active');
    }

    function renderAddToPlaylistList() {
        const listEl = document.getElementById('addToPlaylistList');
        listEl.innerHTML = '';
        if (!playlistsData.length) {
            listEl.innerHTML = `<p class="empty-hint">${t('no_playlists_create_below')}</p>`;
            return;
        }
        playlistsData.forEach(pl => {
            const item = document.createElement('div');
            item.className = 'storage-item';
            item.innerHTML = `
                <div class="storage-item-icon">
                    <svg viewBox="0 0 24 24"><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"/></svg>
                </div>
                <div class="storage-item-info">
                    <div class="storage-item-label">${pl.name}</div>
                    <div class="storage-item-path">${pl.count} ${t('song_count_suffix')}</div>
                </div>
                <div class="storage-item-check"><svg viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg></div>
            `;
            item.onclick = () => addSongToPlaylist(pl.id, item);
            listEl.appendChild(item);
        });
    }

    async function addSongToPlaylist(playlistId, itemEl) {
        if (!actionSheetContext) return;
        const statusEl = document.getElementById('addToPlaylistStatus');
        statusEl.style.color = '#6b7280';
        statusEl.innerText = t('adding');
        try {
            const res = await fetch(`/api/playlists/${playlistId}/songs`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(actionSheetContext.item)
            });
            const data = await res.json();
            if (!res.ok || data.error) {
                statusEl.style.color = '#ef4444';
                statusEl.innerText = data.error || t('add_failed');
                return;
            }
            itemEl.classList.add('active');
            const pl = playlistsData.find(p => p.id === playlistId);
            if (pl) pl.count = (data.songs || []).length;
            statusEl.style.color = '#10b981';
            statusEl.innerText = data.already_exists ? t('already_in_playlist') : t('added_to_playlist');
        } catch (err) {
            statusEl.style.color = '#ef4444';
            statusEl.innerText = t('generic_error_dot');
        }
    }

    async function createPlaylistFromPicker() {
        const input = document.getElementById('newPlaylistNameInput');
        const name = input.value.trim();
        if (!name) return;
        const id = await createPlaylist(name);
        input.value = '';
        if (id) {
            renderAddToPlaylistList();
            document.getElementById('addToPlaylistStatus').style.color = '#10b981';
            document.getElementById('addToPlaylistStatus').innerText = t('playlist_created_now_tap');
        }
    }

    function closeAddToPlaylist() {
        document.getElementById('addToPlaylistOverlay').classList.remove('active');
    }

    // ---------- Çalma motoru (arama / favoriler / çalma listesi / indirilenler ortak kuyruk) ----------
    function getStreamUrl(item) {
        if (item.local) return `/api/local-audio/${encodeURIComponent(item.filename)}`;
        return `/api/stream?url=${encodeURIComponent(item.url)}`;
    }

    // ---------- Karışık Çal (Shuffle) ----------
    let shuffleEnabled = localStorage.getItem('hmusic_shuffle') === '1';
    let shuffleOrder = [];
    let shuffleQueueRef = null;

    function buildShuffleOrder() {
        const n = activeQueue.length;
        const order = Array.from({ length: n }, (_, i) => i);
        for (let i = n - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [order[i], order[j]] = [order[j], order[i]];
        }
        const curPos = order.indexOf(activeQueueIndex);
        if (curPos > 0) {
            order.splice(curPos, 1);
            order.unshift(activeQueueIndex);
        }
        shuffleOrder = order;
        shuffleQueueRef = activeQueue;
    }

    function getAdjacentIndex(direction) {
        if (!shuffleEnabled) return activeQueueIndex + direction;
        if (shuffleQueueRef !== activeQueue || !shuffleOrder.length) buildShuffleOrder();
        const pos = shuffleOrder.indexOf(activeQueueIndex);
        const nextPos = pos + direction;
        if (nextPos < 0 || nextPos >= shuffleOrder.length) return -1;
        return shuffleOrder[nextPos];
    }

    function toggleShuffle() {
        shuffleEnabled = !shuffleEnabled;
        localStorage.setItem('hmusic_shuffle', shuffleEnabled ? '1' : '0');
        document.getElementById('shuffleBtn').classList.toggle('active', shuffleEnabled);
        if (shuffleEnabled) buildShuffleOrder();
    }

    // ---------- Sanatçı etiketi (sanatçı görünümü için) ----------
    function updateArtistTag(item) {
        const tag = document.getElementById('artistNameTag');
        const { artist } = parseArtistFromTitle(item.title || '');
        if (artist && artist !== 'HMusic') {
            tag.innerText = artist;
            tag.dataset.artist = artist;
            tag.style.display = 'block';
        } else {
            tag.style.display = 'none';
            tag.dataset.artist = '';
        }
    }

    let gaplessPreloadedIndex = null;

    function playSong(btn, queueType, index) {
        const list = getQueueArray(queueType);
        const item = list[index];
        if (!item) return;
        if (offlineMode && !item.local) {
            showOfflineBlockedToast();
            return;
        }
        ensureAudioGraph();
        if (currentBtn) resetBtnIcon(currentBtn);
        currentBtn = btn;
        activeQueue = list;
        activeQueueType = queueType;
        activeQueueIndex = index;
        if (btn) setBtnLoading(btn);
        crossfadeInProgress = false;
        gaplessPreloadedIndex = null;
        shuffleQueueRef = null; // kuyruk değişmiş olabilir, sıradaki shuffle çağrısında yeniden karılır
        standbyAudioPlayer.pause();
        standbyAudioPlayer.removeAttribute('src');
        standbyAudioPlayer.volume = 1;
        playerCover.src = item.thumbnail || '';
        setPlayerTitle(item.title);
        updateArtistTag(item);
        playerStatus.innerText = t('preparing');
        playerPanel.classList.add('active');
        activeAudioPlayer.volume = 1;
        activeAudioPlayer.src = getStreamUrl(item);
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
        activeAudioPlayer.play().catch(()=>{});
        updateCanvasBackground(item);
        updateMediaSessionMeta(item);
    }

    function playNext() {
        if (!activeQueue.length || !activeQueueType) return;
        const nextIndex = getAdjacentIndex(1);
        if (nextIndex < 0 || nextIndex >= activeQueue.length) {
            playerStatus.innerText = t('end_of_list');
            return;
        }
        playSong(null, activeQueueType, nextIndex);
    }

    function playPrevious() {
        if (!activeQueue.length || !activeQueueType) return;
        // Şarkı 3 saniyeden fazla ilerlediyse "önceki" başa sarar (yaygın müzik uygulaması davranışı)
        if (activeAudioPlayer.currentTime > 3) {
            activeAudioPlayer.currentTime = 0;
            updateMediaSessionPosition();
            return;
        }
        const prevIndex = getAdjacentIndex(-1);
        if (prevIndex < 0) {
            activeAudioPlayer.currentTime = 0;
            return;
        }
        playSong(null, activeQueueType, prevIndex);
    }

    function startCrossfade() {
        if (crossfadeInProgress) return;
        const nextIndex = getAdjacentIndex(1);
        const nextItem = activeQueue[nextIndex];
        if (!nextItem || (offlineMode && !nextItem.local)) return;
        crossfadeInProgress = true;
        ensureAudioGraph();
        standbyAudioPlayer.src = getStreamUrl(nextItem);
        standbyAudioPlayer.currentTime = 0;
        standbyAudioPlayer.volume = 0;
        standbyAudioPlayer.play().catch(()=>{});
        const fromEl = activeAudioPlayer;
        const toEl = standbyAudioPlayer;
        const totalMs = crossfadeSeconds * 1000;
        const steps = Math.max(6, crossfadeSeconds * 5);
        const stepTime = totalMs / steps;
        let stepCount = 0;
        const fadeTimer = setInterval(() => {
            stepCount++;
            const ratio = stepCount / steps;
            fromEl.volume = Math.max(0, 1 - ratio);
            toEl.volume = Math.min(1, ratio);
            if (stepCount >= steps) {
                clearInterval(fadeTimer);
                fromEl.pause();
                fromEl.currentTime = 0;
                fromEl.volume = 1;
                activeAudioPlayer = toEl;
                standbyAudioPlayer = fromEl;
                activeQueueIndex = nextIndex;
                crossfadeInProgress = false;
                setPlayerTitle(nextItem.title);
                playerCover.src = nextItem.thumbnail || '';
                updateArtistTag(nextItem);
                updateCanvasBackground(nextItem);
                updateMediaSessionMeta(nextItem);
            }
        }, stepTime);
    }

    // ---------- Gapless (aralıksız) geçiş: crossfade kapalıyken sıradaki parça
    // şarkı bitmeden birkaç saniye önce sessizce ön yüklenir; bittiğinde ağ
    // beklemesi olmadan anında geçilir. ----------
    function maybePreloadGapless(el) {
        if (crossfadeSeconds !== 0 || !autoAdvance || crossfadeInProgress) return;
        if (isNaN(el.duration) || (el.duration - el.currentTime) > 3) return;
        const nextIdx = getAdjacentIndex(1);
        if (nextIdx < 0 || nextIdx >= activeQueue.length || gaplessPreloadedIndex === nextIdx) return;
        const nextItem = activeQueue[nextIdx];
        if (!nextItem || (offlineMode && !nextItem.local)) return;
        standbyAudioPlayer.src = getStreamUrl(nextItem);
        standbyAudioPlayer.load();
        gaplessPreloadedIndex = nextIdx;
    }

    function tryGaplessSwap() {
        if (crossfadeSeconds !== 0 || gaplessPreloadedIndex === null) return false;
        const nextIdx = getAdjacentIndex(1);
        if (nextIdx !== gaplessPreloadedIndex || standbyAudioPlayer.readyState < 2) return false;
        const nextItem = activeQueue[nextIdx];
        if (!nextItem) return false;
        const fromEl = activeAudioPlayer;
        const toEl = standbyAudioPlayer;
        activeAudioPlayer = toEl;
        standbyAudioPlayer = fromEl;
        activeQueueIndex = nextIdx;
        gaplessPreloadedIndex = null;
        fromEl.pause();
        fromEl.currentTime = 0;
        fromEl.volume = 1;
        toEl.currentTime = 0;
        toEl.volume = 1;
        toEl.play().catch(() => {});
        currentBtn = null;
        setPlayerTitle(nextItem.title);
        playerCover.src = nextItem.thumbnail || '';
        updateArtistTag(nextItem);
        updateCanvasBackground(nextItem);
        updateMediaSessionMeta(nextItem);
        return true;
    }

    function setBtnLoading(btn) { btn.innerHTML = '<div class="spinner"></div>'; btn.disabled = true; }
    function resetBtnIcon(btn) { btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>'; btn.disabled = false; }

    function onAudioPlaying(e) {
        if (e.target !== activeAudioPlayer) return;
        if (currentBtn) resetBtnIcon(currentBtn);
        playerStatus.innerText = t('playing');
        playIcon.style.display = "none";
        pauseIcon.style.display = "block";
        if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'playing';
    }
    function onAudioPause(e) {
        if (e.target !== activeAudioPlayer) return;
        playerStatus.innerText = t('paused');
        playIcon.style.display = "block";
        pauseIcon.style.display = "none";
        if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    }
    function onAudioTimeUpdate(e) {
        const el = e.target;
        if (el !== activeAudioPlayer) return;
        if (!isNaN(el.duration)) {
            const progress = (el.currentTime / el.duration) * 100;
            seekBar.value = progress;
            currentTimeEl.innerText = formatTime(el.currentTime);
            durationTimeEl.innerText = formatTime(el.duration);
            updateMediaSessionPosition();
            if (crossfadeSeconds > 0 && !crossfadeInProgress && autoAdvance &&
                activeQueue.length && getAdjacentIndex(1) >= 0 &&
                (el.duration - el.currentTime) <= crossfadeSeconds && (el.duration - el.currentTime) > 0.15) {
                startCrossfade();
            } else if (crossfadeSeconds === 0) {
                maybePreloadGapless(el);
            }
        }
    }
    function onAudioEnded(e) {
        if (e.target !== activeAudioPlayer) return;
        if (!autoAdvance) return;
        if (tryGaplessSwap()) return;
        playNext();
    }
    [audioPlayer, audioPlayerAlt].forEach(el => {
        el.addEventListener('playing', onAudioPlaying);
        el.addEventListener('pause', onAudioPause);
        el.addEventListener('timeupdate', onAudioTimeUpdate);
        el.addEventListener('ended', onAudioEnded);
    });
    seekBar.addEventListener('input', () => {
        if (!isNaN(activeAudioPlayer.duration)) {
            activeAudioPlayer.currentTime = (seekBar.value / 100) * activeAudioPlayer.duration;
        }
    });
    function togglePlay() {
        if (activeAudioPlayer.paused) activeAudioPlayer.play();
        else activeAudioPlayer.pause();
    }
    function formatTime(secs) {
        const m = Math.floor(secs / 60);
        const s = Math.floor(secs % 60);
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    // ---------- Ayarlar Paneli ----------
    function toggleSettings(e) {
        if (e) e.stopPropagation();
        document.getElementById('settingsPanel').classList.toggle('active');
    }
    document.addEventListener('click', (e) => {
        const panel = document.getElementById('settingsPanel');
        const btn = document.getElementById('settingsBtn');
        if (panel.classList.contains('active') && !panel.contains(e.target) && e.target !== btn) {
            panel.classList.remove('active');
        }
    });

    // ---------- Çapraz Geçiş (Crossfade) ----------
    function openCrossfadeSettings() {
        document.getElementById('crossfadeSlider').value = crossfadeSeconds;
        document.getElementById('crossfadeValueLabel').innerText = crossfadeSeconds + 's';
        document.getElementById('crossfadeOverlay').classList.add('active');
    }
    function closeCrossfadeSettings() {
        document.getElementById('crossfadeOverlay').classList.remove('active');
    }
    function onCrossfadeChange(val) {
        crossfadeSeconds = parseInt(val, 10);
        localStorage.setItem('hmusic_crossfade', crossfadeSeconds);
        document.getElementById('crossfadeValueLabel').innerText = crossfadeSeconds === 0 ? t('crossfade_off') : crossfadeSeconds + 's';
    }

    // ---------- Önbelleği Temizle ----------
    function formatBytes(bytes) {
        if (!bytes) return '0 MB';
        const mb = bytes / (1024 * 1024);
        if (mb < 1024) return mb.toFixed(1) + ' MB';
        return (mb / 1024).toFixed(2) + ' GB';
    }
    async function openCacheSettings() {
        document.getElementById('cacheOverlay').classList.add('active');
        document.getElementById('cacheStatus').innerText = '';
        document.getElementById('cacheSizeNum').innerText = t('loading');
        try {
            const res = await fetch('/api/cache/info');
            const data = await res.json();
            document.getElementById('cacheSizeNum').innerText = formatBytes(data.size_bytes || 0);
            const limitMb = Math.round((data.limit_bytes || 500 * 1024 * 1024) / (1024 * 1024));
            document.getElementById('cacheLimitSlider').value = limitMb;
            document.getElementById('cacheLimitVal').innerText = limitMb + ' MB';
        } catch (err) {
            document.getElementById('cacheSizeNum').innerText = '—';
        }
    }
    function closeCacheSettings() {
        document.getElementById('cacheOverlay').classList.remove('active');
    }
    async function clearCache() {
        const statusEl = document.getElementById('cacheStatus');
        statusEl.style.color = 'var(--text-muted)';
        statusEl.innerText = t('saving');
        try {
            const res = await fetch('/api/cache/clear', { method: 'POST' });
            const data = await res.json();
            if (!res.ok || data.error) {
                statusEl.style.color = 'var(--danger)';
                statusEl.innerText = data.error || t('change_failed');
                return;
            }
            document.getElementById('cacheSizeNum').innerText = formatBytes(0);
            statusEl.style.color = 'var(--accent)';
            statusEl.innerText = t('saved_prefix') + formatBytes(data.freed_bytes || 0);
        } catch (err) {
            statusEl.style.color = 'var(--danger)';
            statusEl.innerText = t('generic_error_dot');
        }
    }
    function onCacheLimitInput(val) {
        document.getElementById('cacheLimitVal').innerText = val + ' MB';
    }
    let cacheLimitDebounce = null;
    function onCacheLimitChange(val) {
        clearTimeout(cacheLimitDebounce);
        cacheLimitDebounce = setTimeout(async () => {
            try {
                await fetch('/api/cache/limit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ limit_mb: parseInt(val, 10) })
                });
                const infoRes = await fetch('/api/cache/info');
                const info = await infoRes.json();
                document.getElementById('cacheSizeNum').innerText = formatBytes(info.size_bytes || 0);
            } catch (err) { /* sessizce geç, kritik değil */ }
        }, 400);
    }

    // ---------- Uyku Zamanlayıcısı ----------
    let sleepTimerMinutes = 0;
    let sleepTimerDeadline = null;
    let sleepTimerInterval = null;
    let sleepTimerFading = false;

    function openSleepTimerSettings() {
        document.getElementById('settingsPanel').classList.remove('active');
        updateSleepTimerModalNote();
        document.getElementById('sleepTimerOverlay').classList.add('active');
    }
    function closeSleepTimerSettings() {
        document.getElementById('sleepTimerOverlay').classList.remove('active');
    }
    function updateSleepTimerModalNote() {
        const note = document.getElementById('sleepTimerActiveNote');
        if (sleepTimerDeadline) {
            const remainingMs = Math.max(0, sleepTimerDeadline - Date.now());
            const mins = Math.floor(remainingMs / 60000);
            const secs = Math.floor((remainingMs % 60000) / 1000);
            note.style.display = 'block';
            note.innerText = `${t('sleep_timer_active_prefix')}${mins}:${secs < 10 ? '0' : ''}${secs}`;
        } else {
            note.style.display = 'none';
        }
    }
    function setSleepTimer(minutes) {
        clearInterval(sleepTimerInterval);
        sleepTimerFading = false;
        if (!minutes) {
            sleepTimerMinutes = 0;
            sleepTimerDeadline = null;
            updateSleepTimerModalNote();
            closeSleepTimerSettings();
            return;
        }
        sleepTimerMinutes = minutes;
        sleepTimerDeadline = Date.now() + minutes * 60 * 1000;
        sleepTimerInterval = setInterval(sleepTimerTick, 1000);
        updateSleepTimerModalNote();
        closeSleepTimerSettings();
    }
    function sleepTimerTick() {
        if (!sleepTimerDeadline) return;
        const remainingMs = sleepTimerDeadline - Date.now();
        if (remainingMs <= 0 && !sleepTimerFading) {
            sleepTimerFading = true;
            fadeOutAndPause();
            clearInterval(sleepTimerInterval);
            sleepTimerDeadline = null;
        }
    }
    function fadeOutAndPause() {
        const el = activeAudioPlayer;
        const steps = 20;
        let i = 0;
        const timer = setInterval(() => {
            i++;
            el.volume = Math.max(0, 1 - i / steps);
            if (i >= steps) {
                clearInterval(timer);
                el.pause();
                el.volume = 1;
            }
        }, 150);
    }

    // ---------- Çevrimdışı Mod ----------
    let offlineMode = localStorage.getItem('hmusic_offline') === '1';
    function applyOfflineModeUI() {
        document.getElementById('offlineModeToggle').checked = offlineMode;
        const searchBtnTab = document.getElementById('tabSearchBtn');
        searchBtnTab.style.opacity = offlineMode ? '0.4' : '1';
        const hint = document.getElementById('offlineModeHint');
        if (offlineMode) {
            hint.style.display = 'block';
            hint.innerText = t('offline_hint');
        } else {
            hint.style.display = 'none';
        }
    }
    function onOfflineModeToggle() {
        offlineMode = document.getElementById('offlineModeToggle').checked;
        localStorage.setItem('hmusic_offline', offlineMode ? '1' : '0');
        applyOfflineModeUI();
        if (offlineMode && document.getElementById('searchTabContent').classList.contains('active')) {
            switchTab('downloaded');
        }
    }
    function showOfflineBlockedToast() {
        alert(t('offline_blocked'));
    }

    // ---------- İndirilenler ----------
    async function loadDownloadedTab() {
        const listEl = document.getElementById('downloadedList');
        listEl.innerHTML = `<p class="empty-hint">${t('loading')}</p>`;
        try {
            const res = await fetch('/api/downloads/local');
            const data = await res.json();
            downloadedData = (data.items || []).map(x => ({ ...x, local: true }));
            renderCardList(listEl, downloadedData, 'downloaded', t('no_downloads_yet'));
        } catch (err) {
            listEl.innerHTML = `<p class="empty-hint">${t('error_occurred')}</p>`;
        }
    }
    async function deleteLocalDownload(index) {
        const item = downloadedData[index];
        if (!item) return;
        if (!confirm(t('confirm_delete_download'))) return;
        try {
            await fetch(`/api/local-audio/${encodeURIComponent(item.filename)}`, { method: 'DELETE' });
        } catch (err) {}
        loadDownloadedTab();
    }

    // ---------- Şarkı Sözleri ----------
    let currentLyricsTitle = null;
    async function openLyrics() {
        const overlay = document.getElementById('lyricsOverlay');
        const body = document.getElementById('lyricsBody');
        const songTitleEl = document.getElementById('lyricsSongTitle');
        overlay.classList.add('active');
        if (!playerPanel.classList.contains('active') || !playerTitle.innerText || playerTitle.innerText === t('player_title_default')) {
            songTitleEl.innerText = '';
            body.innerHTML = `<p style="color:var(--text-muted); text-align:center; margin-top:20px;">${t('lyrics_no_song')}</p>`;
            return;
        }
        const title = playerTitle.innerText;
        songTitleEl.innerText = title;
        if (currentLyricsTitle === title && body.dataset.loaded === '1') return;
        currentLyricsTitle = title;
        body.dataset.loaded = '0';
        body.innerHTML = `<p style="color:var(--text-muted); text-align:center; margin-top:20px;">${t('loading')}</p>`;
        try {
            const res = await fetch(`/api/lyrics?title=${encodeURIComponent(title)}`);
            const data = await res.json();
            if (currentLyricsTitle !== title) return;
            if (!data.found || !data.lyrics) {
                body.innerHTML = `<p style="color:var(--text-muted); text-align:center; margin-top:20px;">${t('lyrics_not_found')}</p>`;
                return;
            }
            body.innerText = data.lyrics;
            body.dataset.loaded = '1';
        } catch (err) {
            body.innerHTML = `<p style="color:var(--danger); text-align:center; margin-top:20px;">${t('error_occurred')}</p>`;
        }
    }
    function closeLyrics() {
        document.getElementById('lyricsOverlay').classList.remove('active');
    }
    async function copyLyrics() {
        const body = document.getElementById('lyricsBody');
        const text = body.innerText || '';
        if (!text || body.dataset.loaded !== '1') return;
        try {
            await navigator.clipboard.writeText(text);
            const btn = document.getElementById('lyricsCopyBtn');
            const original = t('lyrics_copy');
            btn.innerText = t('lyrics_copied');
            setTimeout(() => { btn.innerText = original; }, 1500);
        } catch (err) { /* pano izni yoksa sessizce geç */ }
    }

    // ---------- Sanatçı Görünümü ----------
    function collectKnownItems() {
        // O an istemcide yüklü olan veriler üzerinden birleştirir: tüm playlist'lerin
        // tam listesi sunucudan çekilmediği için bu, uygulama genelinde eksiksiz bir
        // "sanatçı veritabanı" değil — favoriler, indirilenler, son arama sonuçları ve
        // açık olan çalma listesindeki şarkılarla sınırlı bir yaklaşık görünümdür.
        const map = new Map();
        [...favoritesData, ...downloadedData, ...searchResults, ...activePlaylistSongs].forEach(item => {
            if (item && item.id) map.set(item.id, item);
        });
        return [...map.values()];
    }
    function openArtistView() {
        const tag = document.getElementById('artistNameTag');
        const artist = tag.dataset.artist;
        if (!artist) return;
        document.getElementById('artistViewTitle').innerText = artist;
        const listEl = document.getElementById('artistViewList');
        const matches = collectKnownItems().filter(item => {
            const parsed = parseArtistFromTitle(item.title || '');
            return parsed.artist.toLowerCase() === artist.toLowerCase();
        });
        if (!matches.length) {
            listEl.innerHTML = `<p class="empty-hint">${t('artist_view_empty')}</p>`;
            artistViewItems = [];
        } else {
            listEl.innerHTML = '';
            artistViewItems = matches;
            matches.forEach((item, i) => {
                const card = document.createElement('div');
                card.className = 'song-card';
                card.innerHTML = songCardHTML(item, 'artistview', i);
                listEl.appendChild(card);
            });
        }
        document.getElementById('artistViewOverlay').classList.add('active');
    }
    function closeArtistView() {
        document.getElementById('artistViewOverlay').classList.remove('active');
    }

    // ---------- Ses Kalitesi (indirme formatı / örnekleme hızı / bit derinliği) ----------
    let audioFormat = localStorage.getItem('hmusic_audio_format') || 'mp3';
    let audioSampleRate = parseInt(localStorage.getItem('hmusic_audio_samplerate') || '44100', 10);
    let audioBitDepth = parseInt(localStorage.getItem('hmusic_audio_bitdepth') || '16', 10);

    function applyAudioQualityUI() {
        ['Mp3', 'Wav', 'Flac'].forEach(f => {
            document.getElementById('fmtBtn' + f).classList.toggle('active', audioFormat === f.toLowerCase());
        });
        [44100, 48000, 96000].forEach(sr => {
            document.getElementById('srBtn' + sr).classList.toggle('active', audioSampleRate === sr);
        });
        [16, 24, 32].forEach(bd => {
            document.getElementById('bdBtn' + bd).classList.toggle('active', audioBitDepth === bd);
        });
        document.getElementById('audioBitDepthRow').style.opacity = audioFormat === 'mp3' ? '0.4' : '1';
        document.getElementById('actionSheetMp3Label').textContent = t('download_mp3').replace('MP3', audioFormat.toUpperCase());
    }
    function setAudioFormat(fmt) {
        audioFormat = fmt;
        localStorage.setItem('hmusic_audio_format', fmt);
        applyAudioQualityUI();
    }
    function setAudioSampleRate(sr) {
        audioSampleRate = sr;
        localStorage.setItem('hmusic_audio_samplerate', sr);
        applyAudioQualityUI();
    }
    function setAudioBitDepth(bd) {
        audioBitDepth = bd;
        localStorage.setItem('hmusic_audio_bitdepth', bd);
        applyAudioQualityUI();
    }
    function openAudioQualitySettings() {
        applyAudioQualityUI();
        document.getElementById('audioQualityOverlay').classList.add('active');
    }
    function closeAudioQualitySettings() {
        document.getElementById('audioQualityOverlay').classList.remove('active');
    }

    // ---------- Tema ----------
    let themeMode = localStorage.getItem('hmusic_theme') || 'system';
    function applyTheme() {
        let effective = themeMode;
        if (themeMode === 'system') {
            effective = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) ? 'light' : 'dark';
        }
        document.documentElement.setAttribute('data-theme', effective);
        document.getElementById('themeBtnSystem').classList.toggle('active', themeMode === 'system');
        document.getElementById('themeBtnDark').classList.toggle('active', themeMode === 'dark');
        document.getElementById('themeBtnLight').classList.toggle('active', themeMode === 'light');
    }
    function setTheme(mode) {
        themeMode = mode;
        localStorage.setItem('hmusic_theme', mode);
        applyTheme();
    }
    function openThemeSettings() {
        document.getElementById('themeOverlay').classList.add('active');
    }
    function closeThemeSettings() {
        document.getElementById('themeOverlay').classList.remove('active');
    }
    if (window.matchMedia) {
        window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
            if (themeMode === 'system') applyTheme();
        });
    }

    // ---------- Hareketli Kapak (Canvas) ----------
    let canvasEnabled = localStorage.getItem('hmusic_canvas') === '1';
    function onCanvasToggle() {
        canvasEnabled = document.getElementById('canvasToggle').checked;
        localStorage.setItem('hmusic_canvas', canvasEnabled ? '1' : '0');
        if (!canvasEnabled) document.getElementById('canvasBg').classList.remove('active');
        else if (playerPanel.classList.contains('active')) document.getElementById('canvasBg').classList.add('active');
    }
    function updateCanvasBackground(item) {
        const bg = document.getElementById('canvasBg');
        const img = document.getElementById('canvasBgImg');
        if (!canvasEnabled || !item.thumbnail) {
            bg.classList.remove('active');
            return;
        }
        img.src = item.thumbnail;
        bg.classList.add('active');
    }

    // ---------- Kilit Ekranı Kontrolleri (Media Session) ----------
    let lockScreenEnabled = localStorage.getItem('hmusic_lockscreen') !== '0';
    function onLockScreenToggle() {
        lockScreenEnabled = document.getElementById('lockScreenToggle').checked;
        localStorage.setItem('hmusic_lockscreen', lockScreenEnabled ? '1' : '0');
        if (!lockScreenEnabled && 'mediaSession' in navigator) {
            navigator.mediaSession.metadata = null;
        } else if (lockScreenEnabled && activeQueue.length && activeQueue[activeQueueIndex]) {
            updateMediaSessionMeta(activeQueue[activeQueueIndex]);
        }
    }
    function parseArtistFromTitle(rawTitle) {
        // YouTube video başlıklarında yaygın "Sanatçı - Şarkı" kalıbını ayırır
        const seps = [' - ', ' – ', ' — ', ' | '];
        for (const sep of seps) {
            if (rawTitle.includes(sep)) {
                const [artist, ...rest] = rawTitle.split(sep);
                const song = rest.join(sep).trim();
                if (artist.trim() && song) return { artist: artist.trim(), song };
            }
        }
        return { artist: 'HMusic', song: rawTitle };
    }
    function buildArtwork(thumbnail) {
        if (!thumbnail) return [];
        return [96, 128, 192, 256, 384, 512].map(size => ({
            src: thumbnail, sizes: `${size}x${size}`, type: 'image/jpeg'
        }));
    }
    function updateMediaSessionMeta(item) {
        if (!lockScreenEnabled || !('mediaSession' in navigator)) return;
        const { artist, song } = parseArtistFromTitle(item.title || '');
        navigator.mediaSession.metadata = new MediaMetadata({
            title: song,
            artist: artist,
            album: 'HMusic',
            artwork: buildArtwork(item.thumbnail)
        });
        navigator.mediaSession.playbackState = activeAudioPlayer.paused ? 'paused' : 'playing';
    }
    function updateMediaSessionPosition() {
        if (!lockScreenEnabled || !('mediaSession' in navigator) || !('setPositionState' in navigator.mediaSession)) return;
        const el = activeAudioPlayer;
        if (isNaN(el.duration) || !isFinite(el.duration) || el.duration <= 0) return;
        try {
            navigator.mediaSession.setPositionState({
                duration: el.duration,
                playbackRate: el.playbackRate || 1,
                position: Math.min(el.currentTime, el.duration)
            });
        } catch (err) { /* konum senkronu opsiyoneldir, hata olursa sessizce geç */ }
    }
    function stopPlayback() {
        activeAudioPlayer.pause();
        activeAudioPlayer.currentTime = 0;
        standbyAudioPlayer.pause();
        standbyAudioPlayer.currentTime = 0;
        playerPanel.classList.remove('active');
        document.getElementById('canvasBg').classList.remove('active');
        if ('mediaSession' in navigator) {
            navigator.mediaSession.playbackState = 'none';
            navigator.mediaSession.metadata = null;
        }
    }
    if ('mediaSession' in navigator) {
        navigator.mediaSession.setActionHandler('play', () => activeAudioPlayer.play());
        navigator.mediaSession.setActionHandler('pause', () => activeAudioPlayer.pause());
        navigator.mediaSession.setActionHandler('previoustrack', () => playPrevious());
        navigator.mediaSession.setActionHandler('nexttrack', () => playNext());
        try {
            navigator.mediaSession.setActionHandler('seekbackward', (details) => {
                activeAudioPlayer.currentTime = Math.max(0, activeAudioPlayer.currentTime - (details.seekOffset || 10));
                updateMediaSessionPosition();
            });
            navigator.mediaSession.setActionHandler('seekforward', (details) => {
                const dur = activeAudioPlayer.duration || Infinity;
                activeAudioPlayer.currentTime = Math.min(dur, activeAudioPlayer.currentTime + (details.seekOffset || 10));
                updateMediaSessionPosition();
            });
            navigator.mediaSession.setActionHandler('seekto', (details) => {
                if (details.seekTime != null) {
                    activeAudioPlayer.currentTime = details.seekTime;
                    updateMediaSessionPosition();
                }
            });
        } catch (err) { /* bazı tarayıcılar seek action'larını desteklemez */ }
        try {
            navigator.mediaSession.setActionHandler('stop', () => stopPlayback());
        } catch (err) { /* bazı tarayıcılar stop action'ını desteklemez */ }
    }

    // ---------- Ekolayzır & 8D (Web Audio API) ----------
    let audioCtx = null;
    let sourceNode = null;
    let sourceNodeAlt = null;
    let eqFilters = [];
    let eqEnabled = false;
    let pannerNode = null;
    let panLFO = null;
    let panLFOGain = null;
    let eightDEnabled = false;
    let eightDSpeed = 8;
    let compressorNode = null;
    let airFilterNode = null;
    let convolverNode = null;
    let dryGain = null;
    let wetGain = null;
    let sumGain = null;
    let widenSplitter = null;
    let widenMerger = null;
    let widenDelay = null;
    let surroundEnabled = false;
    let surroundAmount = 40;
    const eqBandsConfig = [
        { freq: 31, label: '31' },
        { freq: 62, label: '62' },
        { freq: 125, label: '125' },
        { freq: 250, label: '250' },
        { freq: 500, label: '500' },
        { freq: 1000, label: '1K' },
        { freq: 2000, label: '2K' },
        { freq: 4000, label: '4K' },
        { freq: 8000, label: '8K' },
        { freq: 16000, label: '16K' }
    ];
    const eqPresets = {
        flat:   { nameKey: 'preset_flat',   gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
        bass:   { nameKey: 'preset_bass',   gains: [8, 7, 5, 3, 1, 0, -1, -1, -2, -2] },
        vocal:  { nameKey: 'preset_vocal',  gains: [-3, -2, 0, 2, 4, 4, 3, 1, 0, -1] },
        treble: { nameKey: 'preset_treble', gains: [-2, -2, -1, 0, 0, 1, 2, 4, 6, 7] }
    };
    let bassBoost = 0;
    let trebleBoost = 0;
    let bassShelf = null;
    let trebleShelf = null;
    let loudnessEnabled = false;
    let loudnessCompressor = null;
    let loudnessMakeup = null;

    function ensureAudioGraph() {
        if (audioCtx) return;
        try {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            sourceNode = audioCtx.createMediaElementSource(audioPlayer);
            sourceNodeAlt = audioCtx.createMediaElementSource(audioPlayerAlt);

            bassShelf = audioCtx.createBiquadFilter();
            bassShelf.type = 'lowshelf';
            bassShelf.frequency.value = 120;
            bassShelf.gain.value = 0;

            trebleShelf = audioCtx.createBiquadFilter();
            trebleShelf.type = 'highshelf';
            trebleShelf.frequency.value = 8000;
            trebleShelf.gain.value = 0;

            eqFilters = eqBandsConfig.map(band => {
                const f = audioCtx.createBiquadFilter();
                f.type = 'peaking';
                f.frequency.value = band.freq;
                f.Q.value = 1.4;
                f.gain.value = 0;
                return f;
            });
            let prevNode = bassShelf;
            eqFilters.forEach(f => { prevNode.connect(f); prevNode = f; });
            prevNode.connect(trebleShelf);
            prevNode = trebleShelf;

            sourceNode.connect(bassShelf);
            sourceNodeAlt.connect(bassShelf);

            // Sinema Ses (Surround): dinamik/netlik işleme + algoritmik yankı + stereo genişletme
            compressorNode = audioCtx.createDynamicsCompressor();
            compressorNode.threshold.value = -18;
            compressorNode.knee.value = 24;
            compressorNode.ratio.value = 3;
            compressorNode.attack.value = 0.005;
            compressorNode.release.value = 0.25;

            airFilterNode = audioCtx.createBiquadFilter();
            airFilterNode.type = 'highshelf';
            airFilterNode.frequency.value = 9000;
            airFilterNode.gain.value = 0;

            convolverNode = audioCtx.createConvolver();
            convolverNode.normalize = true;
            convolverNode.buffer = createImpulseResponse(audioCtx, 2.2, 2.6);

            dryGain = audioCtx.createGain();
            dryGain.gain.value = 1;
            wetGain = audioCtx.createGain();
            wetGain.gain.value = 0;
            sumGain = audioCtx.createGain();

            widenSplitter = audioCtx.createChannelSplitter(2);
            widenMerger = audioCtx.createChannelMerger(2);
            widenDelay = audioCtx.createDelay(0.05);
            widenDelay.delayTime.value = 0;

            prevNode.connect(compressorNode);
            compressorNode.connect(airFilterNode);
            airFilterNode.connect(dryGain);
            airFilterNode.connect(convolverNode);
            convolverNode.connect(wetGain);
            dryGain.connect(sumGain);
            wetGain.connect(sumGain);
            sumGain.connect(widenSplitter);
            widenSplitter.connect(widenMerger, 0, 0);
            widenSplitter.connect(widenDelay, 1);
            widenDelay.connect(widenMerger, 0, 1);

            // Loudness (algısal ses seviyesi dengeleme): kısık pasajları hafifçe
            // toparlayıp makeup gain ile telafi eder. Kapalıyken tamamen etkisiz
            // (ratio 1, gain 0dB) olacak şekilde ayarlanır — düğüm grafiği yeniden
            // kurulmadan devre dışı bırakılabilsin diye.
            loudnessCompressor = audioCtx.createDynamicsCompressor();
            loudnessCompressor.threshold.value = 0;
            loudnessCompressor.knee.value = 0;
            loudnessCompressor.ratio.value = 1;
            loudnessCompressor.attack.value = 0.01;
            loudnessCompressor.release.value = 0.3;
            loudnessMakeup = audioCtx.createGain();
            loudnessMakeup.gain.value = 1;

            pannerNode = audioCtx.createStereoPanner();
            widenMerger.connect(loudnessCompressor);
            loudnessCompressor.connect(loudnessMakeup);
            loudnessMakeup.connect(pannerNode);
            pannerNode.connect(audioCtx.destination);
        } catch (err) {
            console.error('Audio graph oluşturulamadı:', err);
        }
    }

    function createImpulseResponse(ctx, duration, decay) {
        const rate = ctx.sampleRate;
        const length = Math.floor(rate * duration);
        const impulse = ctx.createBuffer(2, length, rate);
        for (let ch = 0; ch < 2; ch++) {
            const data = impulse.getChannelData(ch);
            for (let i = 0; i < length; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
            }
        }
        return impulse;
    }

    function onSurroundToggle() {
        surroundEnabled = document.getElementById('surroundToggle').checked;
        ensureAudioGraph();
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
        applySurroundAmount();
        document.getElementById('surroundAmountRow').style.display = surroundEnabled ? 'flex' : 'none';
    }

    function applySurroundAmount() {
        if (!wetGain || !widenDelay || !airFilterNode) return;
        if (surroundEnabled) {
            const amt = surroundAmount / 100;
            wetGain.gain.value = amt * 0.55;
            widenDelay.delayTime.value = 0.006 + amt * 0.02;
            airFilterNode.gain.value = amt * 5;
        } else {
            wetGain.gain.value = 0;
            widenDelay.delayTime.value = 0;
            airFilterNode.gain.value = 0;
        }
    }

    function onSurroundAmountChange(val) {
        surroundAmount = parseFloat(val);
        document.getElementById('surroundAmountVal').innerText = surroundAmount + '%';
        applySurroundAmount();
    }

    function start8DEffect() {
        if (!audioCtx || !pannerNode) return;
        stop8DEffect();
        panLFO = audioCtx.createOscillator();
        panLFO.type = 'sine';
        panLFO.frequency.value = 1 / eightDSpeed;
        panLFOGain = audioCtx.createGain();
        panLFOGain.gain.value = 1;
        panLFO.connect(panLFOGain);
        panLFOGain.connect(pannerNode.pan);
        panLFO.start();
    }

    function stop8DEffect() {
        if (panLFO) {
            try { panLFO.stop(); } catch (e) {}
            panLFO.disconnect();
            panLFO = null;
        }
        if (panLFOGain) {
            panLFOGain.disconnect();
            panLFOGain = null;
        }
        if (pannerNode) pannerNode.pan.value = 0;
    }

    function on8DToggle() {
        eightDEnabled = document.getElementById('eightDToggle').checked;
        ensureAudioGraph();
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
        const speedRow = document.getElementById('eightDSpeedRow');
        if (eightDEnabled) {
            start8DEffect();
            speedRow.style.display = 'flex';
        } else {
            stop8DEffect();
            speedRow.style.display = 'none';
        }
    }

    function on8DSpeedChange(val) {
        eightDSpeed = parseFloat(val);
        document.getElementById('eightDSpeedVal').innerText = eightDSpeed + 's';
        if (panLFO) panLFO.frequency.value = 1 / eightDSpeed;
    }

    function onBassBoostChange(val) {
        bassBoost = parseInt(val, 10);
        document.getElementById('bassBoostVal').innerText = `${bassBoost}dB`;
        if (bassShelf) bassShelf.gain.value = bassBoost;
    }

    function onTrebleBoostChange(val) {
        trebleBoost = parseInt(val, 10);
        document.getElementById('trebleBoostVal').innerText = `${trebleBoost}dB`;
        if (trebleShelf) trebleShelf.gain.value = trebleBoost;
    }

    function onLoudnessToggle() {
        loudnessEnabled = document.getElementById('loudnessToggle').checked;
        if (!loudnessCompressor || !loudnessMakeup) return;
        if (loudnessEnabled) {
            loudnessCompressor.threshold.value = -30;
            loudnessCompressor.knee.value = 12;
            loudnessCompressor.ratio.value = 4;
            loudnessMakeup.gain.value = 1.6; // ~4dB telafi kazancı
        } else {
            loudnessCompressor.threshold.value = 0;
            loudnessCompressor.knee.value = 0;
            loudnessCompressor.ratio.value = 1;
            loudnessMakeup.gain.value = 1;
        }
    }

    function buildEqUI() {
        const bandsContainer = document.getElementById('eqBands');
        bandsContainer.innerHTML = '';
        eqBandsConfig.forEach((band, i) => {
            const wrap = document.createElement('div');
            wrap.className = 'eq-band';
            wrap.innerHTML = `
                <span class="eq-band-val" id="eqVal${i}">0dB</span>
                <input type="range" class="eq-band-slider" id="eqSlider${i}" min="-12" max="12" value="0" step="1" orient="vertical">
                <span class="eq-band-freq">${band.label}</span>
            `;
            bandsContainer.appendChild(wrap);
        });
        eqBandsConfig.forEach((band, i) => {
            const slider = document.getElementById(`eqSlider${i}`);
            slider.addEventListener('input', () => {
                const val = parseInt(slider.value, 10);
                document.getElementById(`eqVal${i}`).innerText = `${val}dB`;
                if (eqFilters[i]) eqFilters[i].gain.value = val;
                clearActivePreset();
            });
        });

        const presetsContainer = document.getElementById('eqPresets');
        presetsContainer.innerHTML = '';
        Object.keys(eqPresets).forEach(key => {
            const b = document.createElement('button');
            b.className = 'eq-preset-btn';
            b.id = `preset-${key}`;
            b.innerText = t(eqPresets[key].nameKey);
            b.onclick = () => applyPreset(key);
            presetsContainer.appendChild(b);
        });
    }

    function clearActivePreset() {
        document.querySelectorAll('.eq-preset-btn').forEach(b => b.classList.remove('active'));
    }

    function applyPreset(key) {
        const preset = eqPresets[key];
        if (!preset) return;
        preset.gains.forEach((g, i) => {
            const slider = document.getElementById(`eqSlider${i}`);
            if (slider) slider.value = g;
            document.getElementById(`eqVal${i}`).innerText = `${g}dB`;
            if (eqFilters[i]) eqFilters[i].gain.value = g;
        });
        clearActivePreset();
        const btn = document.getElementById(`preset-${key}`);
        if (btn) btn.classList.add('active');
        if (key !== 'flat' && !eqEnabled) {
            document.getElementById('eqEnabledToggle').checked = true;
            onEqToggle();
        }
    }

    function onEqToggle() {
        eqEnabled = document.getElementById('eqEnabledToggle').checked;
        if (!eqEnabled) {
            eqFilters.forEach(f => { f.gain.value = 0; });
        } else {
            eqBandsConfig.forEach((band, i) => {
                const slider = document.getElementById(`eqSlider${i}`);
                if (slider && eqFilters[i]) eqFilters[i].gain.value = parseInt(slider.value, 10);
            });
        }
    }

    function openEqualizer() {
        ensureAudioGraph();
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
        buildEqUI();
        document.getElementById('eqEnabledToggle').checked = eqEnabled;
        document.getElementById('bassBoostSlider').value = bassBoost;
        document.getElementById('bassBoostVal').innerText = `${bassBoost}dB`;
        document.getElementById('trebleBoostSlider').value = trebleBoost;
        document.getElementById('trebleBoostVal').innerText = `${trebleBoost}dB`;
        document.getElementById('loudnessToggle').checked = loudnessEnabled;
        document.getElementById('eightDToggle').checked = eightDEnabled;
        document.getElementById('eightDSpeedRow').style.display = eightDEnabled ? 'flex' : 'none';
        document.getElementById('eightDSpeedSlider').value = eightDSpeed;
        document.getElementById('eightDSpeedVal').innerText = eightDSpeed + 's';
        document.getElementById('surroundToggle').checked = surroundEnabled;
        document.getElementById('surroundAmountRow').style.display = surroundEnabled ? 'flex' : 'none';
        document.getElementById('surroundAmountSlider').value = surroundAmount;
        document.getElementById('surroundAmountVal').innerText = surroundAmount + '%';
        document.getElementById('settingsPanel').classList.remove('active');
        document.getElementById('eqOverlay').classList.add('active');
    }

    function closeEqualizer() {
        document.getElementById('eqOverlay').classList.remove('active');
    }

    // ---------- İndirme Konumu ----------
    const folderIconSvg = '<svg viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>';

    async function openStorageSettings() {
        document.getElementById('settingsPanel').classList.remove('active');
        document.getElementById('storageOverlay').classList.add('active');
        document.getElementById('storageStatus').innerText = '';
        const listEl = document.getElementById('storageList');
        listEl.innerHTML = `<p style="text-align:center; color:#6b7280; font-size:12px;">${t('loading')}</p>`;
        try {
            const res = await fetch('/api/settings/storage');
            const data = await res.json();
            renderStorageList(data.options || [], data.current || '');
        } catch (err) {
            listEl.innerHTML = `<p style="text-align:center; color:#ef4444; font-size:12px;">${t('storage_load_failed')}</p>`;
        }
    }

    function renderStorageList(options, current) {
        const listEl = document.getElementById('storageList');
        listEl.innerHTML = '';
        if (!options.length) {
            listEl.innerHTML = `<p style="text-align:center; color:#6b7280; font-size:12px;">${t('storage_none_found')}</p>`;
            return;
        }
        options.forEach(opt => {
            const isActive = opt.path === current;
            const item = document.createElement('div');
            item.className = 'storage-item' + (isActive ? ' active' : '');
            item.onclick = () => selectStorage(opt.key, item);
            item.innerHTML = `
                <div class="storage-item-icon">${folderIconSvg}</div>
                <div class="storage-item-info">
                    <div class="storage-item-label">${opt.label}</div>
                    <div class="storage-item-path">${opt.path}</div>
                </div>
                <div class="storage-item-check">
                    <svg viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>
                </div>
            `;
            listEl.appendChild(item);
        });
    }

    async function selectStorage(key, itemEl) {
        const statusEl = document.getElementById('storageStatus');
        statusEl.style.color = '#6b7280';
        statusEl.innerText = t('saving');
        try {
            const res = await fetch('/api/settings/storage', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key })
            });
            const data = await res.json();
            if (!res.ok || data.error) {
                statusEl.style.color = '#ef4444';
                statusEl.innerText = data.error || t('change_failed');
                return;
            }
            document.querySelectorAll('.storage-item').forEach(el => el.classList.remove('active'));
            itemEl.classList.add('active');
            statusEl.style.color = '#10b981';
            statusEl.innerText = t('saved_prefix') + data.current;
        } catch (err) {
            statusEl.style.color = '#ef4444';
            statusEl.innerText = t('generic_error_dot');
        }
    }

    function closeStorageSettings() {
        document.getElementById('storageOverlay').classList.remove('active');
    }

    loadLibrary();
    loadPopular();
    applyStaticTexts();
    applyTheme();
    applyAudioQualityUI();
    document.getElementById('canvasToggle').checked = canvasEnabled;
    document.getElementById('lockScreenToggle').checked = lockScreenEnabled;
    document.getElementById('shuffleBtn').classList.toggle('active', shuffleEnabled);
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/sw.js').catch(() => {});
    }
