"""Arka planda çalışan indirme işleri (job) ve ilerleme takibi.

Flask'ın senkron GET isteği yerine: istemci önce bir iş başlatır (job_id
alır), sonra o iş bitene kadar ilerleme yüzdesini polling ile sorar. Böylece
büyük dosyalarda indirme ilerleme çubuğu gösterebiliyoruz.

Basit ve tek süreçli (Termux/kişisel kullanım) bir kurulum için bellek-içi
bir sözlük yeterlidir; iş kaydı process yeniden başladığında sıfırlanır.
"""
import threading
import time
import uuid

import config
import youtube
import artwork

_jobs = {}
_jobs_lock = threading.Lock()
_JOB_TTL_SECONDS = 15 * 60  # tamamlanmış/başarısız işler bu süre sonunda temizlenir


def _set_job(job_id, **fields):
    with _jobs_lock:
        job = _jobs.setdefault(job_id, {})
        job.update(fields)
        job['updated_at'] = time.time()


def get_job(job_id):
    with _jobs_lock:
        job = _jobs.get(job_id)
        return dict(job) if job else None


def _cleanup_old_jobs():
    now = time.time()
    with _jobs_lock:
        stale = [jid for jid, j in _jobs.items()
                 if j.get('status') in ('done', 'error') and now - j.get('updated_at', now) > _JOB_TTL_SECONDS]
        for jid in stale:
            del _jobs[jid]


def _progress_hook_factory(job_id):
    def hook(d):
        status = d.get('status')
        if status == 'downloading':
            total = d.get('total_bytes') or d.get('total_bytes_estimate')
            downloaded = d.get('downloaded_bytes') or 0
            percent = round((downloaded / total) * 100, 1) if total else None
            _set_job(job_id, status='downloading', percent=percent,
                     speed=d.get('speed'), eta=d.get('eta'))
        elif status == 'finished':
            # yt-dlp indirme bitti, şimdi postprocessing (mp3/flac dönüşümü) sürüyor
            _set_job(job_id, status='processing', percent=99)
    return hook


def start_audio_download_job(url, fmt, sample_rate, bit_depth):
    job_id = uuid.uuid4().hex
    _set_job(job_id, status='queued', percent=0, kind='audio')
    _cleanup_old_jobs()

    def run():
        try:
            hook = _progress_hook_factory(job_id)
            file_path, title = youtube.process_youtube_audio(
                url, config.DOWNLOAD_FOLDER, fmt=fmt,
                sample_rate=sample_rate, bit_depth=bit_depth, progress_hook=hook
            )
            video_id = extract_and_save_meta(url, title)
            thumbnail_url = f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg" if video_id else None
            if thumbnail_url:
                artwork.embed_artwork(file_path, fmt, thumbnail_url)
            _set_job(job_id, status='done', percent=100, file_path=file_path, title=title, fmt=fmt)
        except Exception as e:
            _set_job(job_id, status='error', error=str(e))

    threading.Thread(target=run, daemon=True).start()
    return job_id


def start_video_download_job(url):
    job_id = uuid.uuid4().hex
    _set_job(job_id, status='queued', percent=0, kind='video')
    _cleanup_old_jobs()

    def run():
        try:
            hook = _progress_hook_factory(job_id)
            file_path, title = youtube.process_youtube_mp4(url, progress_hook=hook)
            _set_job(job_id, status='done', percent=100, file_path=file_path, title=title, fmt='mp4')
        except Exception as e:
            _set_job(job_id, status='error', error=str(e))

    threading.Thread(target=run, daemon=True).start()
    return job_id


def extract_and_save_meta(url, title):
    video_id = youtube.extract_video_id(url)
    if video_id:
        meta = config.load_downloads_meta()
        meta[video_id] = title
        config.save_downloads_meta(meta)
    return video_id
