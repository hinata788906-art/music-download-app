"""Admin paneli için daha sağlam kimlik doğrulama.

Öncekinden farkı:
- Anahtar karşılaştırması artık `secrets.compare_digest` ile sabit zamanlı
  (zamanlama saldırılarına karşı) yapılıyor; önceki `==` karşılaştırması
  teorik olarak buna açıktı.
- Anahtar URL'de her istek için taşınmak yerine (tarayıcı geçmişinde,
  Referer başlığında, sunucu loglarında sızabilir) bir kez doğrulanıp
  imzalı bir session çerezine dönüştürülüyor; sonraki istekler URL'de
  anahtar taşımıyor.
- Başarısız deneme kilitlenmesi: bir IP kısa sürede çok fazla yanlış
  anahtar denerse geçici olarak engellenir (brute-force koruması).
"""
import time
import secrets as secrets_module
from collections import defaultdict
from flask import session

import config

FAILED_ATTEMPT_WINDOW = 15 * 60  # 15 dakika
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 15 * 60

_failed_attempts = defaultdict(list)  # ip -> [zaman damgaları]


def is_locked_out(ip):
    now = time.time()
    _failed_attempts[ip] = [t for t in _failed_attempts[ip] if now - t < LOCKOUT_SECONDS]
    return len(_failed_attempts[ip]) >= MAX_FAILED_ATTEMPTS


def record_failed_attempt(ip):
    _failed_attempts[ip].append(time.time())


def clear_failed_attempts(ip):
    _failed_attempts.pop(ip, None)


def verify_key(provided_key):
    if not provided_key:
        return False
    return secrets_module.compare_digest(str(provided_key), config.ADMIN_SECRET_KEY)


def is_authenticated():
    return session.get('is_admin') is True


def login(ip):
    session['is_admin'] = True
    session.permanent = True
    clear_failed_attempts(ip)


def logout():
    session.pop('is_admin', None)
