"""YouTube ile ilgili işlemler: URL doğrulama, arama, mp3/mp4 indirme."""
import os
import re
import time
import urllib.parse
import concurrent.futures
import requests
import yt_dlp

import config

AUDIO_EXTENSIONS = ('mp3', 'wav', 'flac')
# Çalma (stream) önbelleğinde dönüştürülmeden tutulan orijinal ses uzantıları.
STREAM_EXTENSIONS = ('m4a', 'webm', 'opus', 'ogg', 'mp3')

# Arama sonucu sayısı: hem Invidious hem de yt-dlp fallback'i bu sınırı kullanır.
SEARCH_RESULT_LIMIT = 25

# Aynı arama sorgusu bu süre boyunca önbellekten dönülür (saniye).
SEARCH_CACHE_TTL = 300
_search_cache = {}  # query -> {'data': [...], 'ts': float}

# Popüler/trend şarkılar listesi bu süre boyunca önbellekte tutulur (saniye).
POPULAR_CACHE_TTL = 1800
_popular_cache = {}  # lang -> {'data': [...], 'ts': float}


def is_valid_youtube_url(url):
    if not url:
        return False
    parsed = urllib.parse.urlparse(url)
    allowed_domains = ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be']
    return parsed.netloc in allowed_domains


def extract_video_id(url):
    """URL'den ağa hiç gitmeden video id'sini çıkarmaya çalışır (ucuz önbellek kontrolü için)."""
    try:
        parsed = urllib.parse.urlparse(url)
        if parsed.netloc == 'youtu.be':
            return parsed.path.strip('/').split('/')[0] or None
        qs = urllib.parse.parse_qs(parsed.query)
        if 'v' in qs:
            return qs['v'][0]
        m = re.search(r'/(shorts|embed)/([A-Za-z0-9_-]{6,})', parsed.path)
        if m:
            return m.group(2)
    except Exception:
        pass
    return None


def find_existing_audio(video_id):
    """Aynı video daha önce indirilmiş veya akış için önbelleklenmişse dosya yolunu döner.

    Önce kalıcı indirmeler klasörüne (kullanıcı zaten indirmişse baştan indirmeye
    gerek yok), sonra akış önbelleğine bakar. Bulunamazsa None döner.
    """
    if not video_id:
        return None
    for folder in (config.DOWNLOAD_FOLDER, config.CACHE_FOLDER):
        for ext in AUDIO_EXTENSIONS:
            candidate = os.path.join(folder, f"{video_id}.{ext}")
            if os.path.isfile(candidate):
                return candidate
    return None


def find_existing_stream(video_id, folder=None):
    """Çalma önbelleğinde (dönüştürülmemiş, orijinal formatta) dosya var mı bakar."""
    if not video_id:
        return None
    folder = folder or config.CACHE_FOLDER
    for ext in STREAM_EXTENSIONS:
        candidate = os.path.join(folder, f"{video_id}.{ext}")
        if os.path.isfile(candidate):
            return candidate
    return None


def _fetch_first_invidious_json(nodes, timeout=2.5):
    """Invidious node'larına PARALEL istek atar, ilk başarılı JSON yanıtı döner.

    Sıralı denemek yerine hepsini aynı anda başlatıp en hızlı yanıt verenin
    sonucunu kullanmak, bir node yavaş/çökükken beklenen toplam süreyi
    (node_sayısı * timeout yerine tek bir timeout'a) düşürür.
    """
    if not nodes:
        return None

    def fetch(node):
        try:
            res = requests.get(node, timeout=timeout)
            if res.status_code == 200:
                return res.json()
        except Exception:
            return None
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(nodes)) as executor:
        futures = [executor.submit(fetch, node) for node in nodes]
        try:
            for future in concurrent.futures.as_completed(futures, timeout=timeout + 0.5):
                data = future.result()
                if data:
                    return data
        except concurrent.futures.TimeoutError:
            pass
    return None


def search_youtube(clean_query):
    """Invidious node'larına paralel istek atar, hepsi başarısız olursa yt-dlp
    arama sonucuna düşer. Aynı sorgu kısa süre önbelleklenir.
    Sonuç listesini (list) veya bulunamazsa None döner."""
    cache_key = clean_query.lower().strip()
    now = time.time()
    cached = _search_cache.get(cache_key)
    if cached and (now - cached['ts']) < SEARCH_CACHE_TTL:
        return cached['data']

    invidious_nodes = [
        f"https://inv.tux.pizza/api/v1/search?q={clean_query}&type=video",
        f"https://vid.puffyan.us/api/v1/search?q={clean_query}&type=video"
    ]

    results = None
    data = _fetch_first_invidious_json(invidious_nodes)
    if data:
        results = []
        for item in data[:SEARCH_RESULT_LIMIT]:
            results.append({
                'id': item.get('videoId'),
                'title': item.get('title'),
                'url': f"https://www.youtube.com/watch?v={item.get('videoId')}",
                'thumbnail': f"https://i.ytimg.com/vi/{item.get('videoId')}/hqdefault.jpg"
            })

    if results is None:
        ydl_opts = {
            'skip_download': True,
            'quiet': True,
            'extract_flat': True,
            'extractor_args': {'youtube': {'player_client': ['android']}}
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(f"ytsearch{SEARCH_RESULT_LIMIT}:{clean_query}", download=False)
            results = []
            for entry in info.get('entries', []):
                if entry:
                    results.append({
                        'id': entry.get('id'),
                        'title': entry.get('title'),
                        'url': f"https://www.youtube.com/watch?v={entry.get('id')}",
                        'thumbnail': f"https://i.ytimg.com/vi/{entry.get('id')}/hqdefault.jpg"
                    })

    if results:
        _search_cache[cache_key] = {'data': results, 'ts': now}
    return results


def get_popular_songs(limit=SEARCH_RESULT_LIMIT, lang='tr'):
    """Şu anda popüler/trend olan şarkıları döner.

    lang='tr' iken Türkiye bölgesine göre trend listesi, lang='en' iken
    uluslararası (ABD bölgesi) trend listesi getirilir. Önce Invidious'un
    trend (type=music) uç noktasına paralel istek atar, olmazsa yt-dlp ile
    dile uygun bir 'trend müzik' aramasına düşer. Sonuç dil başına birkaç
    dakika önbelleklenir ki ana ekran her açıldığında dış servislere gidilmesin.
    """
    lang = 'en' if lang == 'en' else 'tr'
    now = time.time()
    cached = _popular_cache.get(lang)
    if cached and (now - cached['ts']) < POPULAR_CACHE_TTL:
        return cached['data']

    region = 'US' if lang == 'en' else 'TR'
    invidious_nodes = [
        f"https://inv.tux.pizza/api/v1/trending?type=Music&region={region}",
        f"https://vid.puffyan.us/api/v1/trending?type=Music&region={region}"
    ]

    results = []
    data = _fetch_first_invidious_json(invidious_nodes)
    if data:
        for item in data[:limit]:
            video_id = item.get('videoId')
            if not video_id:
                continue
            results.append({
                'id': video_id,
                'title': item.get('title'),
                'url': f"https://www.youtube.com/watch?v={video_id}",
                'thumbnail': f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
            })

    if not results:
        fallback_query = "top global hits 2026 trending music" if lang == 'en' else "popüler şarkılar 2026 trend müzik"
        try:
            ydl_opts = {
                'skip_download': True,
                'quiet': True,
                'extract_flat': True,
                'extractor_args': {'youtube': {'player_client': ['android']}}
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch{limit}:{fallback_query}", download=False)
                for entry in info.get('entries', []):
                    if entry:
                        results.append({
                            'id': entry.get('id'),
                            'title': entry.get('title'),
                            'url': f"https://www.youtube.com/watch?v={entry.get('id')}",
                            'thumbnail': f"https://i.ytimg.com/vi/{entry.get('id')}/hqdefault.jpg"
                        })
        except Exception:
            results = []

    if results:
        _popular_cache[lang] = {'data': results, 'ts': now}
    return results


def process_youtube_stream(url, folder=None):
    """Hızlı çalma (streaming) için orijinal ses konteynerini (m4a/webm/opus)
    HİÇBİR dönüştürme yapmadan indirir.

    process_youtube_audio'nun aksine ffmpeg ile mp3'e dönüştürme adımını
    (FFmpegExtractAudio) atlar — bu adım tüm dosyanın indirilip yeniden
    kodlanmasını gerektirdiği için çalmaya başlama süresini uzatan asıl
    sebepti. Tarayıcılar m4a/webm'i zaten native oynatabildiği için bu adıma
    sadece kalıcı indirme (download) tarafında ihtiyaç var, çalma tarafında
    değil.
    """
    folder = folder or config.CACHE_FOLDER
    video_id = extract_video_id(url)
    if video_id:
        existing = find_existing_stream(video_id, folder)
        if existing:
            meta = config.load_downloads_meta()
            title = meta.get(video_id, video_id)
            return existing, title

    out_template = f"{folder}/%(id)s.%(ext)s"
    ydl_opts = {
        'format': 'bestaudio[ext=m4a]/bestaudio/best',
        'outtmpl': out_template,
        'quiet': True,
        'extractor_args': {'youtube': {'player_client': ['android', 'ios']}}
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        ext = info.get('ext', 'm4a')
        file_path = f"{folder}/{info['id']}.{ext}"
        return file_path, info.get('title', 'muzik')


def process_youtube_audio(url, folder=None, fmt='mp3', sample_rate=None, bit_depth=None, progress_hook=None):
    """MP3 (kayıplı, hızlı) veya WAV/FLAC (kayıpsız) olarak indirir.

    Aynı video, aynı klasörde (indirilenler ya da akış önbelleği) zaten varsa
    yeniden indirmez — doğrudan mevcut dosyayı döner (indirme/akış önbellek
    optimizasyonu).

    Not: Kaynak her durumda YouTube'un kendi (kayıplı) ses akışıdır. WAV/FLAC
    seçimi orijinal kaydı geri getirmez; sadece MP3'e ek bir kayıplı sıkıştırma
    turu eklenmesini önler ve dosyayı istenen örnekleme hızı/bit derinliğinde
    teslim eder.

    progress_hook: yt-dlp'nin progress_hooks imzasıyla uyumlu, opsiyonel bir
    callback (indirme ilerlemesini bir işe (job) yansıtmak için kullanılır).
    """
    folder = folder or config.DOWNLOAD_FOLDER
    fmt = fmt if fmt in ('mp3', 'wav', 'flac') else 'mp3'

    video_id = extract_video_id(url)
    if video_id:
        existing = os.path.join(folder, f"{video_id}.{fmt}")
        if os.path.isfile(existing):
            meta = config.load_downloads_meta()
            title = meta.get(video_id, video_id)
            if progress_hook:
                progress_hook({'status': 'finished', 'filename': existing, '_cached': True})
            return existing, title

    out_template = f"{folder}/%(id)s.%(ext)s"

    postprocessor = {'key': 'FFmpegExtractAudio', 'preferredcodec': fmt}
    if fmt == 'mp3':
        postprocessor['preferredquality'] = '192'

    extra_args = []
    if sample_rate in (44100, 48000, 96000):
        extra_args += ['-ar', str(sample_rate)]
    if fmt == 'wav' and bit_depth in (16, 24, 32):
        codec = {16: 'pcm_s16le', 24: 'pcm_s24le', 32: 'pcm_f32le'}[bit_depth]
        extra_args += ['-acodec', codec]
    elif fmt == 'flac' and bit_depth in (24, 32):
        extra_args += ['-sample_fmt', 's32']

    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': out_template,
        'postprocessors': [postprocessor],
        'quiet': True,
        'extractor_args': {'youtube': {'player_client': ['android', 'ios']}}
    }
    if extra_args:
        ydl_opts['postprocessor_args'] = {'ffmpeg': extra_args}
    if progress_hook:
        ydl_opts['progress_hooks'] = [progress_hook]

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        file_path = f"{folder}/{info['id']}.{fmt}"
        return file_path, info.get('title', 'muzik')


def process_youtube_mp3(url, folder=None):
    return process_youtube_audio(url, folder, fmt='mp3')


def process_youtube_mp4(url, progress_hook=None):
    video_id = extract_video_id(url)
    if video_id:
        existing = os.path.join(config.DOWNLOAD_FOLDER, f"{video_id}_video.mp4")
        if os.path.isfile(existing):
            meta = config.load_downloads_meta()
            title = meta.get(video_id, video_id)
            if progress_hook:
                progress_hook({'status': 'finished', 'filename': existing, '_cached': True})
            return existing, title

    out_template = f"{config.DOWNLOAD_FOLDER}/%(id)s_video.%(ext)s"
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': out_template,
        'quiet': True,
        'extractor_args': {'youtube': {'player_client': ['android', 'ios']}}
    }
    if progress_hook:
        ydl_opts['progress_hooks'] = [progress_hook]
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        file_path = f"{config.DOWNLOAD_FOLDER}/{info['id']}_video.mp4"
        return file_path, info.get('title', 'video')
