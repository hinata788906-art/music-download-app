"""Gizli admin paneli: kullanım istatistikleri ve IP banlama."""
from flask import Blueprint, request, render_template, redirect, url_for, abort

import config
import stats
import admin_auth
from extensions import limiter

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/admin', methods=['GET'])
def admin_panel():
    ip = request.remote_addr

    # Konsoldan kopyalanan ?key=... linkiyle gelen ilk giriş: doğrulanırsa
    # session'a çevrilip anahtar URL'den temizlenmiş haliyle yönlendirilir.
    url_key = request.args.get('key')
    if url_key and not admin_auth.is_authenticated():
        if admin_auth.is_locked_out(ip):
            return render_template('admin_login.html', locked_out=True, error=None)
        if admin_auth.verify_key(url_key):
            admin_auth.login(ip)
            return redirect(url_for('admin.admin_panel'))
        admin_auth.record_failed_attempt(ip)
        return render_template('admin_login.html', locked_out=False, error="Geçersiz anahtar.")

    if not admin_auth.is_authenticated():
        return render_template('admin_login.html', locked_out=admin_auth.is_locked_out(ip), error=None)

    total_users = len(stats.user_stats)
    total_plays = sum(u['plays'] for u in stats.user_stats.values())
    total_mp3 = sum(u['mp3'] for u in stats.user_stats.values())
    total_mp4 = sum(u['mp4'] for u in stats.user_stats.values())

    return render_template(
        'admin.html',
        users=stats.user_stats,
        total_users=total_users,
        total_plays=total_plays,
        total_mp3=total_mp3,
        total_mp4=total_mp4
    )


@admin_bp.route('/admin/login', methods=['POST'])
@limiter.limit("10 per minute")
def admin_login():
    ip = request.remote_addr
    if admin_auth.is_locked_out(ip):
        return render_template('admin_login.html', locked_out=True, error=None)
    provided_key = request.form.get('key', '')
    if admin_auth.verify_key(provided_key):
        admin_auth.login(ip)
        return redirect(url_for('admin.admin_panel'))
    admin_auth.record_failed_attempt(ip)
    locked = admin_auth.is_locked_out(ip)
    return render_template('admin_login.html', locked_out=locked,
                            error=None if locked else "Geçersiz anahtar.")


@admin_bp.route('/admin/logout')
def admin_logout():
    admin_auth.logout()
    return redirect(url_for('admin.admin_panel'))


def _require_admin():
    if not admin_auth.is_authenticated():
        abort(404)


@admin_bp.route('/admin/ban')
def admin_ban_ip():
    _require_admin()
    ip = request.args.get('ip')
    if ip in stats.user_stats:
        stats.user_stats[ip]['banned'] = True
        stats.save_stats(stats.user_stats)
    return redirect(url_for('admin.admin_panel'))


@admin_bp.route('/admin/unban')
def admin_unban_ip():
    _require_admin()
    ip = request.args.get('ip')
    if ip in stats.user_stats:
        stats.user_stats[ip]['banned'] = False
        stats.save_stats(stats.user_stats)
    return redirect(url_for('admin.admin_panel'))
