"""Şarkı sözü getirme.

Sözler, üçüncü taraf bir web sitesinden kazınmaz (scraping) — bunun yerine
geliştiricilerin kullanımı için sunulan, ücretsiz ve açık lyrics.ovh API'sine
istek atılır (https://lyrics.ovh). Bu, kendi ToS'una göre erişime kapalı bir
platformu izinsiz kazımaktan farklıdır: veri, tam da bu amaçla sağlanan bir
uç noktadan istenir.

Not: Bu ücretsiz/gayrı resmi bir topluluk servisidir; her şarkı için sonuç
bulunacağı veya sonucun doğru olacağı garanti edilmez.
"""
import re
import urllib.parse
import requests

LYRICS_API_BASE = "https://api.lyrics.ovh/v1"

_NOISE_PATTERN = re.compile(
    r'\((?:[^()]*)\)|\[(?:[^\[\]]*)\]|\b(official( music)? video|official audio|lyrics?|hd|4k|mv|prod\.[^,]*)\b',
    re.IGNORECASE
)


def _clean(text):
    text = _NOISE_PATTERN.sub('', text)
    text = re.sub(r'\s+', ' ', text).strip(' -–—|')
    return text.strip()


def _parse_artist_title(video_title):
    """YouTube video başlıklarında yaygın olan 'Sanatçı - Şarkı' kalıbını ayrıştırır."""
    for sep in [' - ', ' – ', ' — ', ' | ']:
        if sep in video_title:
            artist, title = video_title.split(sep, 1)
            return _clean(artist), _clean(title)
    return '', _clean(video_title)


def fetch_lyrics(video_title):
    """Verilen video başlığı için şarkı sözünü döner, bulunamazsa None."""
    artist, title = _parse_artist_title(video_title)
    if not title:
        return None
    try:
        url = f"{LYRICS_API_BASE}/{urllib.parse.quote(artist)}/{urllib.parse.quote(title)}"
        res = requests.get(url, timeout=5)
        if res.status_code == 200:
            data = res.json()
            lyrics = (data.get('lyrics') or '').strip()
            if lyrics:
                return lyrics
    except Exception:
        pass
    return None
